# SimpleTestMod (Forge 1.16.5)

Mod test — bam phim **G** trong game de bat/tat hieu ung tint mau am + vignette.
Hieu ung chay qua he thong post-processing shader NOI BO cua chinh Minecraft
(cai Mojang dung cho Nausea/Blindness), goi bang code Java qua
`gameRenderer.loadShader(...)` — KHONG dung OptiFine, KHONG can thu muc shaderpacks.

## Cach build (tren may tinh, khong phai dien thoai)

1. Copy toan bo thu muc `src/` nay de len tren thu muc `src/` cua mot project
   **Forge 1.16.5 MDK** co san (tai MDK tai files.minecraftforge.net neu chua co).
   - Neu ban da co MDK roi, chi can copy de/ghi de thu muc `src/main/java` va
     `src/main/resources` vao dung vi tri.
2. Mo terminal trong thu muc goc project, chay:
   - Windows: `gradlew.bat build`
   - Linux/Mac: `./gradlew build`
3. File `.jar` ra o `build/libs/<tenmod>-1.0.0.jar`
4. Bo file `.jar` do vao thu muc `mods/` cua Minecraft (ben canh OptiFine
   forge jar cua ban, khong xung dot vi day la 2 mod doc lap).

## Luu y quan trong — noi de sai nhat

- Phan **logic Java** (dang ky phim, bat/tat shader) dung theo API Forge
  chinh thuc cho 1.16.5, kha chac chan dung.
- Phan **file GLSL/json shader** (`warmtint.vsh/.fsh/.json`) minh viet dua
  theo dung quy uoc cua he thong PostChain trong vanilla Minecraft, nhung
  minh KHONG co moi truong de compile/chay thu that su (khong co Minecraft,
  khong co GPU trong sandbox nay). Neu khi test bi:
  - Man hinh den / crash khi bam G → rat co the do sai ten uniform/attribute
    trong file `.vsh`/`.fsh` (Mojang co the doi ten field giua cac ban 1.16.x).
  - Bao doc gioi han "shader X khong ton tai" → kiem tra dung namespace
    `simpletestmod` khop giua file json va thu muc.
  - Log loi trong console/log file se cho biet chinh xac dong nao sai —
    gui log do lai, minh sua tiep theo dung loi that.

## Cau truc file

```
src/main/java/com/testmod/simpletest/
  SimpleTestMod.java      <- entry point mod
  ClientSetup.java        <- dang ky phim G, goi loadShader()/stopUseShader()

src/main/resources/
  META-INF/mods.toml
  pack.mcmeta
  assets/simpletestmod/shaders/post/warmtint.json     <- pipeline post-effect
  assets/simpletestmod/shaders/program/warmtint.json  <- khai bao vertex/fragment
  assets/simpletestmod/shaders/program/warmtint.vsh   <- vertex shader
  assets/simpletestmod/shaders/program/warmtint.fsh   <- fragment shader (tint+vignette)
```
