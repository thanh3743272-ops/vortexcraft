package com.testmod.simpletest;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.glfw.GLFW;

/**
 * Dang ky phim G de bat/tat hieu ung shader.
 * Dung he thong post-processing shader co san trong vanilla Minecraft
 * (giong co che Mojang dung cho Nausea/Blindness), khong lien quan OptiFine.
 */
public class ClientSetup {

    private static final KeyBinding TOGGLE_KEY = new KeyBinding(
            "key.simpletestmod.toggle",
            KeyConflictContext.IN_GAME,
            GLFW.GLFW_KEY_G,
            "key.categories.simpletestmod"
    );

    private static boolean shaderOn = false;

    public static void init() {
        ClientRegistry.registerKeyBinding(TOGGLE_KEY);
        MinecraftForge.EVENT_BUS.register(ClientSetup.class);
    }

    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        if (TOGGLE_KEY.isPressed()) {
            Minecraft mc = Minecraft.getInstance();
            if (!shaderOn) {
                mc.gameRenderer.loadShader(new ResourceLocation("simpletestmod", "shaders/post/warmtint.json"));
                shaderOn = true;
                if (mc.player != null) {
                    mc.player.sendStatusMessage(
                            net.minecraft.util.text.StringTextComponent.getTextComponentOrEmpty("[SimpleTestMod] Shader: ON"),
                            true
                    );
                }
            } else {
                mc.gameRenderer.stopUseShader();
                shaderOn = false;
                if (mc.player != null) {
                    mc.player.sendStatusMessage(
                            net.minecraft.util.text.StringTextComponent.getTextComponentOrEmpty("[SimpleTestMod] Shader: OFF"),
                            true
                    );
                }
            }
        }
    }
}
