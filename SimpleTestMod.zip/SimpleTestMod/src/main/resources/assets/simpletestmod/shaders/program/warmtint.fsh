#version 150

uniform sampler2D DiffuseSampler;

in vec2 texCoord;

out vec4 fragColor;

void main(){
    vec4 base = texture(DiffuseSampler, texCoord);

    vec2 centered = texCoord - vec2(0.5);
    float vignette = 1.0 - dot(centered, centered) * 1.3;
    vignette = clamp(vignette, 0.0, 1.0);

    vec3 color = base.rgb * vec3(1.2, 0.95, 0.7);
    color *= vignette;

    fragColor = vec4(color, base.a);
}
