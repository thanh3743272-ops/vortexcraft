package com.stalkerhorror.entity;

import com.stalkerhorror.entity.ai.AvoidSightGoal;
import com.stalkerhorror.entity.ai.ListenGoal;
import com.stalkerhorror.entity.ai.StalkGoal;
import com.stalkerhorror.handler.FearLevelManager;
import com.stalkerhorror.init.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.goal.LookAtGoal;
import net.minecraft.entity.ai.goal.LookRandomlyGoal;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

/**
 * The Stalker: a horror entity that lurks near the player, disappears when
 * looked at directly, and only closes in once the player's "fear level"
 * has escalated enough. It never attacks in melee by default - the horror
 * comes from presence and environmental disruption, not combat.
 */
public class StalkerEntity extends MonsterEntity {

    // How close it's willing to get depends on the current escalation stage.
    private int ticksSinceLastTeleport = 0;

    public StalkerEntity(EntityType<? extends MonsterEntity> type, World world) {
        super(type, world);
        this.experienceValue = 0;
        this.setNoAI(false);
        this.enablePersistence();
    }

    public static AttributeModifierMap.MutableAttribute setCustomAttributes() {
        // NOTE: this static helper's exact name depends on your mapping channel
        // (official vs MCP). If this line doesn't resolve, open MonsterEntity in
        // your IDE and look for the single static method returning
        // AttributeModifierMap.MutableAttribute (it's usually named something like
        // createMonsterAttributes() in official mappings) and swap it in here.
        return MonsterEntity.func_234295_eP_()
                .createMutableAttribute(Attributes.MAX_HEALTH, 40.0D)
                .createMutableAttribute(Attributes.MOVEMENT_SPEED, 0.28D)
                .createMutableAttribute(Attributes.FOLLOW_RANGE, 64.0D)
                .createMutableAttribute(Attributes.ARMOR, 0.0D);
    }

    @Override
    protected void registerGoals() {
        // Order matters: higher priority (lower number) runs first.
        this.goalSelector.addGoal(0, new AvoidSightGoal(this));
        this.goalSelector.addGoal(1, new StalkGoal(this));
        this.goalSelector.addGoal(2, new ListenGoal(this));
        this.goalSelector.addGoal(3, new LookAtGoal(this, PlayerEntity.class, 12.0F));
        this.goalSelector.addGoal(4, new LookRandomlyGoal(this));
    }

    @Override
    public boolean isNoDespawnRequired() {
        // We manage its lifetime ourselves via fear level / distance, not vanilla despawn rules.
        return true;
    }

    @Override
    public boolean canDespawn(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.STALKER_AMBIENT.get();
    }

    @Override
    protected float getSoundVolume() {
        return 0.6F;
    }

    /**
     * Teleports the entity to a position that is out of the given player's
     * direct line of sight, preferably still within "creepy" range so it
     * can be glimpsed again soon after.
     */
    public boolean teleportOutOfSight(PlayerEntity player) {
        if (ticksSinceLastTeleport < 20) {
            return false; // don't teleport too rapidly, it should feel deliberate, not glitchy
        }

        ServerWorld world = (ServerWorld) this.world;
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = this.rand.nextDouble() * Math.PI * 2;
            double dist = 10 + this.rand.nextDouble() * 14; // stay in the 10-24 block "dread" ring
            double x = player.getPosX() + Math.cos(angle) * dist;
            double z = player.getPosZ() + Math.sin(angle) * dist;
            BlockPos.Mutable pos = new BlockPos.Mutable((int) x, (int) player.getPosY(), (int) z);

            // find solid ground near that column
            for (int dy = 4; dy >= -4; dy--) {
                BlockPos candidate = pos.add(0, dy, 0);
                if (world.getBlockState(candidate.down()).isSolid()
                        && world.isAirBlock(candidate)
                        && world.isAirBlock(candidate.up())) {
                    boolean canSee = player.canEntityBeSeen(this) || this.getDistanceSq(player) < 4.0D;
                    this.setPositionAndUpdate(candidate.getX() + 0.5, candidate.getY(), candidate.getZ() + 0.5);
                    ticksSinceLastTeleport = 0;
                    world.spawnParticle(ParticleTypes.SMOKE, this.getPosX(), this.getPosY() + 1, this.getPosZ(),
                            8, 0.2, 0.4, 0.2, 0.01);
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        ticksSinceLastTeleport++;

        // While it exists nearby, it slowly raises the fear level for any player close enough.
        if (!this.world.isRemote) {
            for (PlayerEntity player : this.world.getEntitiesWithinAABB(PlayerEntity.class,
                    this.getBoundingBox().grow(48))) {
                double dist = this.getDistance(player);
                if (dist < 40) {
                    FearLevelManager.increase(player, dist < 16 ? 2 : 1);
                }
            }
        }
    }

    public int getFearStage(PlayerEntity player) {
        return FearLevelManager.getStage(player);
    }
}
