package com.stalkerhorror.entity.ai;

import com.stalkerhorror.entity.StalkerEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.vector.Vector3d;

import java.util.EnumSet;

/**
 * Classic "SCP-173 / Weeping Angel" rule: if a player is looking roughly at
 * the entity AND within range, it teleports somewhere just out of sight
 * instead of standing still. Only active once fear stage >= 1, so the very
 * first encounter can still let the player get a clean, deliberate look.
 */
public class AvoidSightGoal extends Goal {

    private static final double TRIGGER_RANGE = 26.0D;
    private static final double VIEW_DOT_THRESHOLD = 0.85D; // ~30 degree cone

    private final StalkerEntity stalker;

    public AvoidSightGoal(StalkerEntity stalker) {
        this.stalker = stalker;
        this.setMutexFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean shouldExecute() {
        PlayerEntity player = stalker.world.getClosestPlayer(stalker, TRIGGER_RANGE);
        if (player == null || player.isSpectator() || player.isCreative()) {
            return false;
        }
        if (stalker.getFearStage(player) < 1) {
            return false;
        }
        return isBeingWatched(player);
    }

    @Override
    public void tick() {
        PlayerEntity player = stalker.world.getClosestPlayer(stalker, TRIGGER_RANGE);
        if (player != null) {
            stalker.teleportOutOfSight(player);
        }
    }

    @Override
    public boolean shouldContinueExecuting() {
        return false; // one-shot per activation, goal system will re-select it next tick if still watched
    }

    private boolean isBeingWatched(PlayerEntity player) {
        Vector3d lookVec = player.getLookVec().normalize();
        Vector3d toEntity = stalker.getPositionVec()
                .add(0, stalker.getHeight() / 2.0, 0)
                .subtract(player.getEyePosition(1.0F))
                .normalize();
        double dot = lookVec.dotProduct(toEntity);
        return dot > VIEW_DOT_THRESHOLD && player.canEntityBeSeen(stalker);
    }
}
