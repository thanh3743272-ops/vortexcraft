package com.stalkerhorror.entity.render;

import com.stalkerhorror.StalkerHorrorMod;
import com.stalkerhorror.entity.StalkerEntity;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.model.ZombieModel;
import net.minecraft.util.ResourceLocation;

/**
 * We deliberately reuse the vanilla humanoid/zombie model rather than
 * authoring a brand new one from scratch - it keeps this buildable without
 * a separate Blockbench modeling pass. Swap ZombieModel + the texture path
 * below for a custom model/texture later if you want a distinct silhouette.
 */
public class StalkerRenderer extends MobRenderer<StalkerEntity, ZombieModel<StalkerEntity>> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(StalkerHorrorMod.MOD_ID, "textures/entity/stalker.png");

    public StalkerRenderer(EntityRendererManager manager) {
        super(manager, new ZombieModel<>(0.0F, false), 0.5F);
    }

    @Override
    public ResourceLocation getEntityTexture(StalkerEntity entity) {
        return TEXTURE;
    }
}
