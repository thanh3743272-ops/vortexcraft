package com.stalkerhorror.entity.ai;

import com.stalkerhorror.entity.StalkerEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;

import java.util.EnumSet;

/**
 * Follows the player at range without ever quite catching up - except at
 * fear stage 3, where the leash shortens dramatically and it starts closing
 * the gap for real (paired with a jumpscare/chase feel).
 */
public class StalkGoal extends Goal {

    private final StalkerEntity stalker;
    private PlayerEntity target;

    public StalkGoal(StalkerEntity stalker) {
        this.stalker = stalker;
        this.setMutexFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean shouldExecute() {
        target = stalker.world.getClosestPlayer(stalker, 48.0D);
        return target != null && !target.isSpectator() && !target.isCreative();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return target != null && target.isAlive() && stalker.getDistance(target) < 64.0D;
    }

    @Override
    public void tick() {
        if (target == null) return;

        int stage = stalker.getFearStage(target);
        double desiredDistance;
        double speed;

        switch (stage) {
            case 3:
                desiredDistance = 3.0D;   // closing in for real
                speed = 1.15D;
                break;
            case 2:
                desiredDistance = 14.0D;
                speed = 1.0D;
                break;
            default:
                desiredDistance = 22.0D;  // stays comfortably at the edge of visibility
                speed = 0.9D;
        }

        double currentDistance = stalker.getDistance(target);
        stalker.getLookController().setLookPositionWithEntity(target, 30.0F, 30.0F);

        if (currentDistance > desiredDistance + 4.0D) {
            stalker.getNavigator().tryMoveToEntityLiving(target, speed);
        } else if (currentDistance < desiredDistance - 4.0D && stage < 3) {
            // too close for comfort at low fear stages - back off instead of standing in view
            double dx = stalker.getPosX() - target.getPosX();
            double dz = stalker.getPosZ() - target.getPosZ();
            stalker.getNavigator().tryMoveToXYZ(
                    stalker.getPosX() + dx, stalker.getPosY(), stalker.getPosZ() + dz, speed);
        }
    }
}
