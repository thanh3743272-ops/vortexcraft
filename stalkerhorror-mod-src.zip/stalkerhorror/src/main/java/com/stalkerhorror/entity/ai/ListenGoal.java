package com.stalkerhorror.entity.ai;

import com.stalkerhorror.entity.StalkerEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.vector.Vector3d;

import java.util.EnumSet;

/**
 * Rather than hooking the full vanilla sound-event system (heavy for a
 * single mod), this approximates "hearing" the player: fast movement
 * (running/sprinting) or sneaking-breaks nearby generate a directional pull
 * even when the stalker has no direct line of sight. Keeps it relevant
 * indoors / behind walls, which is where a lot of the dread should live.
 */
public class ListenGoal extends Goal {

    private final StalkerEntity stalker;
    private Vector3d lastKnownNoisePos;
    private int cooldown;

    public ListenGoal(StalkerEntity stalker) {
        this.stalker = stalker;
        this.setMutexFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean shouldExecute() {
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        PlayerEntity player = stalker.world.getClosestPlayer(stalker, 32.0D);
        if (player == null) return false;

        boolean isNoisy = player.isSprinting() || player.getMotion().lengthSquared() > 0.02
                || (!player.isSneaking() && player.getMotion().horizontalMag() > 0.005);

        if (isNoisy && !player.canEntityBeSeen(stalker)) {
            lastKnownNoisePos = player.getPositionVec();
            return true;
        }
        return false;
    }

    @Override
    public boolean shouldContinueExecuting() {
        return lastKnownNoisePos != null && !stalker.getNavigator().noPath();
    }

    @Override
    public void startExecuting() {
        if (lastKnownNoisePos != null) {
            stalker.getNavigator().tryMoveToXYZ(lastKnownNoisePos.x, lastKnownNoisePos.y, lastKnownNoisePos.z, 0.85D);
        }
    }

    @Override
    public void resetTask() {
        cooldown = 40; // don't re-trigger instantly, gives a "searching" pause
        lastKnownNoisePos = null;
    }
}
