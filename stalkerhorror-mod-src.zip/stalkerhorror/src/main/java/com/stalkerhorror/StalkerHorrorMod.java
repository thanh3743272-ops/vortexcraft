package com.stalkerhorror;

import com.stalkerhorror.entity.render.StalkerRenderer;
import com.stalkerhorror.handler.AmbientHorrorHandler;
import com.stalkerhorror.handler.DoorPhantomHandler;
import com.stalkerhorror.handler.FlickerLightHandler;
import com.stalkerhorror.init.ModEntityTypes;
import com.stalkerhorror.init.ModSounds;
import net.minecraftforge.client.registry.RenderingRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(StalkerHorrorMod.MOD_ID)
public class StalkerHorrorMod {

    public static final String MOD_ID = "stalkerhorror";
    public static final Logger LOGGER = LogManager.getLogger();

    public StalkerHorrorMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Registries
        ModEntityTypes.ENTITY_TYPES.register(modEventBus);
        ModSounds.SOUND_EVENTS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::clientSetup);
        modEventBus.addListener(this::registerAttributes);

        // World / server tick handlers run on the main Forge bus
        MinecraftForge.EVENT_BUS.register(new DoorPhantomHandler());
        MinecraftForge.EVENT_BUS.register(new FlickerLightHandler());
        MinecraftForge.EVENT_BUS.register(new AmbientHorrorHandler());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("Stalker Horror: common setup complete");
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        // Reuse the vanilla zombie-shaped biped model with our own texture/renderer.
        RenderingRegistry.registerEntityRenderingHandler(ModEntityTypes.STALKER.get(), StalkerRenderer::new);
    }

    private void registerAttributes(final net.minecraftforge.event.entity.EntityAttributeCreationEvent event) {
        event.put(ModEntityTypes.STALKER.get(), com.stalkerhorror.entity.StalkerEntity.setCustomAttributes().create());
    }
}
