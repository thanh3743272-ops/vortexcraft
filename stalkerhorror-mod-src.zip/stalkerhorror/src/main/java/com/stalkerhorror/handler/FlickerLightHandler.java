package com.stalkerhorror.handler;

import com.stalkerhorror.entity.StalkerEntity;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.RedstoneLampBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Random;

/**
 * Flickers lit blocks (redstone lamps, campfires) near a player once fear
 * stage 1+ is reached. Torches are intentionally skipped since vanilla
 * torches can't be toggled without breaking them, and breaking player
 * builds would cross from "spooky" into "destructive/annoying" territory.
 */
public class FlickerLightHandler {

    private static final Random RANDOM = new Random();
    private int counter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        counter++;
        if (counter % 20 != 0) return;

        for (ServerWorld world : event.getServer().getWorlds()) {
            for (PlayerEntity player : world.getPlayers()) {
                if (FearLevelManager.getStage(player) < 1) continue;
                if (RANDOM.nextInt(5) != 0) continue;

                List<StalkerEntity> nearby = world.getEntitiesWithinAABB(StalkerEntity.class,
                        player.getBoundingBox().grow(48));
                if (nearby.isEmpty()) continue;

                BlockPos center = player.getPosition();
                for (BlockPos pos : BlockPos.getAllInBoxMutable(center.add(-6, -3, -6), center.add(6, 3, 6))) {
                    if (world.getBlockState(pos).getBlock() instanceof RedstoneLampBlock) {
                        boolean lit = world.getBlockState(pos).get(BlockStateProperties.LIT);
                        world.setBlockState(pos, world.getBlockState(pos).with(BlockStateProperties.LIT, !lit), 3);
                        return;
                    }
                    if (world.getBlockState(pos).getBlock() instanceof CampfireBlock) {
                        boolean lit = world.getBlockState(pos).get(BlockStateProperties.LIT);
                        world.setBlockState(pos, world.getBlockState(pos).with(BlockStateProperties.LIT, !lit), 3);
                        return;
                    }
                }
            }
        }
    }
}
