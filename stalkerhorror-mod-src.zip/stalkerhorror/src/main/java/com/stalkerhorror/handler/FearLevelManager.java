package com.stalkerhorror.handler;

import net.minecraft.entity.player.PlayerEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple in-memory fear tracker, keyed by player UUID.
 * Stage 0 = calm, Stage 1 = uneasy (ambient sounds/light flicker only),
 * Stage 2 = watched (doors, closer stalking), Stage 3 = hunted (chase/jumpscare).
 *
 * Not persisted across server restarts on purpose - each session builds
 * dread from zero again.
 */
public class FearLevelManager {

    private static final Map<UUID, Integer> FEAR = new ConcurrentHashMap<>();

    public static final int STAGE_1_THRESHOLD = 200;   // ~10 seconds of exposure at rate 1
    public static final int STAGE_2_THRESHOLD = 900;
    public static final int STAGE_3_THRESHOLD = 2200;
    private static final int MAX_FEAR = 3000;

    public static void increase(PlayerEntity player, int amount) {
        FEAR.merge(player.getUniqueID(), amount, (old, add) -> Math.min(MAX_FEAR, old + add));
    }

    public static void decay(PlayerEntity player, int amount) {
        FEAR.computeIfPresent(player.getUniqueID(), (id, old) -> Math.max(0, old - amount));
    }

    public static int getFear(PlayerEntity player) {
        return FEAR.getOrDefault(player.getUniqueID(), 0);
    }

    public static int getStage(PlayerEntity player) {
        int fear = getFear(player);
        if (fear >= STAGE_3_THRESHOLD) return 3;
        if (fear >= STAGE_2_THRESHOLD) return 2;
        if (fear >= STAGE_1_THRESHOLD) return 1;
        return 0;
    }

    public static void reset(PlayerEntity player) {
        FEAR.remove(player.getUniqueID());
    }
}
