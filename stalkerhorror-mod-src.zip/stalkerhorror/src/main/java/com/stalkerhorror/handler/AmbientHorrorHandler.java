package com.stalkerhorror.handler;

import com.stalkerhorror.entity.StalkerEntity;
import com.stalkerhorror.init.ModSounds;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Random;

/**
 * Plays directional "phantom" sounds - footsteps with nobody there,
 * whispers, an occasional heartbeat at high fear stages - at an offset
 * position near the player so they can't immediately pinpoint the source.
 */
public class AmbientHorrorHandler {

    private static final Random RANDOM = new Random();
    private int counter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        counter++;
        if (counter % 15 != 0) return;

        for (ServerWorld world : event.getServer().getWorlds()) {
            for (PlayerEntity player : world.getPlayers()) {
                int stage = FearLevelManager.getStage(player);
                if (stage < 1) continue;

                List<StalkerEntity> nearby = world.getEntitiesWithinAABB(StalkerEntity.class,
                        player.getBoundingBox().grow(48));
                if (nearby.isEmpty()) continue;

                // chance scales with fear stage: more frequent scares as it escalates
                int chanceOutOf = stage == 3 ? 8 : stage == 2 ? 14 : 22;
                if (RANDOM.nextInt(chanceOutOf) != 0) continue;

                SoundEvent sound = pickSound(stage);
                BlockPos origin = randomNearbyOffset(player.getPosition());
                world.playSound(null, origin, sound, SoundCategory.HOSTILE,
                        0.9F, 0.8F + RANDOM.nextFloat() * 0.4F);
            }
        }
    }

    private SoundEvent pickSound(int stage) {
        if (stage >= 3 && RANDOM.nextBoolean()) {
            return ModSounds.HEARTBEAT.get();
        }
        return RANDOM.nextBoolean() ? ModSounds.FAKE_FOOTSTEP.get() : ModSounds.WHISPER.get();
    }

    private BlockPos randomNearbyOffset(BlockPos center) {
        int dx = RANDOM.nextInt(9) - 4;
        int dz = RANDOM.nextInt(9) - 4;
        return center.add(dx, 0, dz);
    }
}
