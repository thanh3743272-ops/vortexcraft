package com.stalkerhorror.handler;

import com.stalkerhorror.entity.StalkerEntity;
import com.stalkerhorror.init.ModSounds;
import net.minecraft.block.DoorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Random;

/**
 * Once a player's fear stage reaches 1+, doors near them (but out of their
 * direct view) have a small chance per tick-window of creaking open or
 * slamming shut on their own - purely cosmetic, does not require a stalker
 * to be physically adjacent, which sells the "something is doing this to me"
 * feeling even after the entity itself has retreated.
 */
public class DoorPhantomHandler {

    private static final Random RANDOM = new Random();
    private int counter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        counter++;
        if (counter % 30 != 0) return; // check roughly every 1.5s, not every tick

        for (ServerWorld world : event.getServer().getWorlds()) {
            for (PlayerEntity player : world.getPlayers()) {
                if (FearLevelManager.getStage(player) < 1) continue;
                if (RANDOM.nextInt(6) != 0) continue; // don't do it every check, keep it sparse

                List<StalkerEntity> nearbyStalkers = world.getEntitiesWithinAABB(StalkerEntity.class,
                        player.getBoundingBox().grow(64));
                if (nearbyStalkers.isEmpty()) continue;

                BlockPos center = player.getPosition();
                BlockPos target = null;
                for (BlockPos pos : BlockPos.getAllInBoxMutable(center.add(-8, -2, -8), center.add(8, 2, 8))) {
                    if (world.getBlockState(pos).getBlock() instanceof DoorBlock) {
                        target = pos.toImmutable();
                        break;
                    }
                }
                if (target == null) continue;

                boolean currentlyOpen = world.getBlockState(target).get(DoorBlock.OPEN);
                world.setBlockState(target, world.getBlockState(target).with(DoorBlock.OPEN, !currentlyOpen), 10);
                world.playSound(null, target, ModSounds.DOOR_CREAK.get(), SoundCategory.HOSTILE, 0.8F,
                        0.7F + RANDOM.nextFloat() * 0.3F);
            }
        }
    }
}
