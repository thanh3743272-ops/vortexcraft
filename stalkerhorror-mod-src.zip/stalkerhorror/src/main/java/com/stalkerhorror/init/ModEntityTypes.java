package com.stalkerhorror.init;

import com.stalkerhorror.StalkerHorrorMod;
import com.stalkerhorror.entity.StalkerEntity;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModEntityTypes {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, StalkerHorrorMod.MOD_ID);

    public static final RegistryObject<EntityType<StalkerEntity>> STALKER = ENTITY_TYPES.register("stalker",
            () -> EntityType.Builder.create(StalkerEntity::new, EntityClassification.MONSTER)
                    .size(0.6F, 1.95F)
                    .setTrackingRange(80)
                    .setUpdateInterval(3)
                    .setShouldReceiveVelocityUpdates(true)
                    .immuneToFire()
                    .build(StalkerHorrorMod.MOD_ID + ":stalker"));
}
