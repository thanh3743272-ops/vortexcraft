package com.stalkerhorror.init;

import com.stalkerhorror.StalkerHorrorMod;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StalkerHorrorMod.MOD_ID);

    public static final RegistryObject<SoundEvent> WHISPER = register("whisper");
    public static final RegistryObject<SoundEvent> FAKE_FOOTSTEP = register("fake_footstep");
    public static final RegistryObject<SoundEvent> DOOR_CREAK = register("door_creak");
    public static final RegistryObject<SoundEvent> STALKER_AMBIENT = register("stalker_ambient");
    public static final RegistryObject<SoundEvent> HEARTBEAT = register("heartbeat");

    private static RegistryObject<SoundEvent> register(String name) {
        ResourceLocation id = new ResourceLocation(StalkerHorrorMod.MOD_ID, name);
        return SOUND_EVENTS.register(name, () -> new SoundEvent(id));
    }
}
