# VortexCraft v1.2.0 — Forge mod cho Minecraft 1.16.5

Mod nhỏ thêm 2 thứ:

1. **Vortex Staff** (`vortexcraft:vortex_staff`) — item cầm tay, có **2 chế độ**,
   và **TỰ TIẾN HÓA** theo số quái bị hạ trong lúc cầm nó (lưu trong chính cây gậy,
   đổi gậy khác là mất tiến độ):

   | Giai đoạn | Tên | Số quái cần |
   |---|---|---|
   | 0 | Gậy Xoáy Thô Sơ | 0 |
   | 1 | Gậy Xoáy Thức Tỉnh | 10 |
   | 2 | Trượng Xoáy Tinh Luyện | 30 |
   | 3 | Trượng Xoáy Cổ Đại | 60 |
   | 4 | Trượng Hư Không Tối Thượng | 100 |

   Càng tiến hóa: hình dáng (texture) đổi đẹp hơn, bán kính hút xa hơn, lực phóng
   mạnh hơn, tia năng lượng bắn xa hơn/mạnh hơn/phá được khối cứng hơn, cooldown
   ngắn hơn. Ở **giai đoạn 4 (tối đa)** mở khóa 2 chiêu tối thượng:
   - Chế độ hút: buông ra kích thêm 1 đợt **sóng xung kích** lan rộng quanh cụm,
     đẩy văng + gây sát thương cả sinh vật đứng gần mà chưa bị hút.
   - Chế độ tia: bắn thêm 1 **tia phụ chếch sang bên** → tạo tia đôi.

   Xem tooltip (giữ chuột vào item trong túi đồ) để coi tiến độ hiện tại.

   **Chế độ Hút xoáy** (giữ chuột phải bình thường, KHÔNG giữ Shift):
   - Hút mob/item lại, cho chúng bay lơ lửng **XOAY TRÒN thành 1 cụm nhỏ ngay phía
     trước mặt** (cách mắt ~4 khối, ngang tầm nhìn) — không dính sát người nên
     không che khuất tầm nhìn.
   - Buông chuột ra: phóng văng cả cụm ra xa theo hướng đang nhìn. Giữ càng lâu
     (tối đa ~2 giây) thì lực phóng càng mạnh.

   **Chế độ Tia năng lượng** (giữ SHIFT rồi giữ chuột phải):
   - Đầu gậy sáng dần lên theo thời gian sạc (hạt sáng end_rod).
   - Buông chuột: bắn tia thẳng về phía trước, xuyên phá các khối "mềm" trên đường
     đi, gây sát thương + đẩy lùi + đốt cháy nhẹ sinh vật trúng tia.

   Cả 2 chế độ đều có cooldown ngắn sau khi dùng (giảm dần theo giai đoạn).
2. **Void Crystal Ore** (`vortexcraft:void_crystal_ore`) — khối quặng phát sáng nhẹ (light level 7),
   thi thoảng bắn hạt particle portal, khi đập ra "Void Crystal" (rương random 1-3, cộng Fortune).
   Cần cuốc sắt trở lên để khai thác.
3. Công thức chế: 1 Void Crystal + 2 Blaze Rod → 1 Vortex Staff (xem
   `src/main/resources/data/vortexcraft/recipes/vortex_staff.json`, bạn chỉnh lại tùy ý).

## Texture

Đã có sẵn 3 texture PNG 16x16 (pixel art tự vẽ bằng code, phong cách tối giản kiểu vanilla)
trong `src/main/resources/assets/vortexcraft/textures/`, nên bạn build là chạy được luôn,
không cần tự vẽ gì thêm. Nếu muốn đẹp hơn thì tự thay ảnh vào đúng 3 đường dẫn đó:

```
textures/item/vortex_staff.png
textures/item/void_crystal.png
textures/block/void_crystal_ore.png
```

## Cách build & chạy thử

Cần cài **JDK 8** (Forge 1.16.5 yêu cầu Java 8) và Gradle sẽ tự tải qua wrapper.

```bash
# Trong thư mục gốc của project (nơi có build.gradle)
./gradlew genEclipseRuns    # hoặc genIntellijRuns nếu dùng IntelliJ
./gradlew runClient         # mở game Minecraft với mod đã load để test
```

Nếu dùng IntelliJ IDEA: mở thư mục này như một Gradle project, đợi Gradle sync xong,
rồi chạy run configuration "Minecraft Client" được tự sinh ra.

Để build ra file `.jar` cài vào Forge client/server bình thường:

```bash
./gradlew build
# file .jar nằm ở build/libs/vortexcraft-1.0.0.jar
```

## Cấu trúc project

```
build.gradle              -> cấu hình Forge Gradle (Forge 1.16.5-36.2.34, mappings official)
src/main/java/...         -> code Java (mod chính, item, block, đăng ký registry)
src/main/resources/
  META-INF/mods.toml      -> khai báo thông tin mod
  assets/vortexcraft/     -> model, blockstate, lang (thiếu texture PNG - xem trên)
  data/vortexcraft/       -> loot table, recipe
  data/minecraft/tags/    -> gắn tag mineable/pickaxe + needs_iron_tool cho ore
```

## Ý tưởng mở rộng thêm (nếu muốn)

- Cho Vortex Staff giảm độ bền (durability) mỗi lần dùng thay vì chỉ cooldown.
- Thêm world generation để Void Crystal Ore tự sinh ra trong hang động/Nether.
- Thêm hiệu ứng ngược: giữ Shift + right-click để "đẩy" thay vì "hút".
