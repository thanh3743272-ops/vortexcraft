# VortexCraft v1.3.0 — Forge mod cho Minecraft 1.16.5

Mod nhỏ thêm 2 thứ:

1. **Vortex Staff** (`vortexcraft:vortex_staff`) — **TỰ TIẾN HÓA** theo số quái bị hạ
   trong lúc cầm nó (lưu trong chính cây gậy, đổi gậy khác là mất tiến độ):

   | Giai đoạn | Tên | Số quái cần |
   |---|---|---|
   | 0 | Gậy Xoáy Thô Sơ | 0 |
   | 1 | Gậy Xoáy Thức Tỉnh | 10 |
   | 2 | Trượng Xoáy Tinh Luyện | 30 |
   | 3 | Trượng Xoáy Cổ Đại | 60 |
   | 4 | Trượng Hư Không Tối Thượng | 100 |

   Càng tiến hóa: texture đổi đẹp hơn (ở cấp 4 có hiệu ứng nhấp nháy sáng-tối),
   hút xa hơn, phóng mạnh hơn, tia bắn xa/mạnh/phá khối cứng hơn, cooldown ngắn lại.

   **Bảng điều khiển** (tổ hợp Shift / giữ / bấm nhanh / đánh thường):

   | Thao tác | Chiêu |
   |---|---|
   | Bấm nhanh chuột phải (không Shift) | **Khiên Phản** — phá đạn/mũi tên gần, đẩy lùi quái, tự giáp kháng ngắn |
   | Giữ chuột phải, thả ra (không Shift) | **Hút Xoáy** — hút quái/item xoay tròn phía trước mặt rồi phóng văng |
   | Giữ chuột phải TỐI ĐA (~2s), thả ra | **Hố Đen** — thay vì phóng ngay, tạo 1 điểm hút cố định vài giây rồi nổ tung |
   | Bấm nhanh + Shift | **Chớp Dịch Chuyển** — dịch người về trước, nổ nhẹ + gây damage quanh chỗ đáp |
   | Giữ + Shift, thả ra | **Tia Năng Lượng** — bắn tia xuyên phá khối mềm, gây damage + đốt |
   | Đánh thường (chuột trái) | **Chém Xuyên** — trúng thêm quái đứng gần mục tiêu, hất sang 2 bên |
   | Passive (tự động, từ cấp 3) | **Vệ Tinh Hộ Vệ** — tự dò & tấn công quái gần nhất mỗi ~2 giây |

   Xem tooltip (giữ chuột vào item trong túi đồ) để coi tiến độ + bảng điều khiển.
2. **Void Crystal Ore** (`vortexcraft:void_crystal_ore`) — khối quặng phát sáng nhẹ (light level 7),
   thi thoảng bắn hạt particle portal, khi đập ra "Void Crystal" (rương random 1-3, cộng Fortune).
   Cần cuốc sắt trở lên để khai thác.
3. Công thức chế: 1 Void Crystal + 2 Blaze Rod → 1 Vortex Staff (xem
   `src/main/resources/data/vortexcraft/recipes/vortex_staff.json`, bạn chỉnh lại tùy ý).

## Texture & Model 3D

Vortex Staff dùng **model 3D thật** (không phải icon 2D dẹt) — mỗi giai đoạn là 1 khối
cán (rod) + 1 khối lõi năng lượng (orb) ghép lại, có texture riêng (`textures/item/rod_0..4.png`
và `orb_0..4.png`), càng lên cấp cao càng thêm chi tiết trang trí (móng vuốt giữ lõi, sao vệ
tinh bay quanh...). Ở cấp 4 lõi còn tự nhấp nháy sáng-tối (đổi qua lại giữa `orb_4.png` và
`orb_4_bright.png` mỗi ~0.5 giây). Tất cả đã có sẵn, build là chạy được ngay, không cần tự vẽ gì.

Ngoài ra khi tung chiêu (bắn tia, hút xoáy, hố đen...) màn hình sẽ **rung nhẹ** theo độ mạnh
của chiêu — xử lý ở phía client (`client/ClientEffects.java` + `client/ClientEvents.java`),
không cần gói tin mạng vì tận dụng cơ chế dự đoán phía client có sẵn của Minecraft.

## Cách build & chạy thử

Cần cài **JDK 8** (Forge 1.16.5 yêu cầu Java 8) và Gradle sẽ tự tải qua wrapper.

```bash
# Trong thư mục gốc của project (nơi có build.gradle)
./gradlew genEclipseRuns    # hoặc genIntellijRuns nếu dùng IntelliJ
./gradlew runClient         # mở game Minecraft với mod đã load để test
```

Nếu dùng IntelliJ IDEA: mở thư mục này như một Gradle project, đợi Gradle sync xong,
rồi chạy run configuration "Minecraft Client" được tự sinh ra.

Để build ra file `.jar` cài vào Forge client/server bình thường:

```bash
./gradlew build
# file .jar nằm ở build/libs/vortexcraft-1.3.0.jar
```

## Cấu trúc project

```
build.gradle              -> cấu hình Forge Gradle (Forge 1.16.5-36.2.34, mappings official)
src/main/java/...         -> code Java (mod chính, item, block, đăng ký registry)
src/main/resources/
  META-INF/mods.toml      -> khai báo thông tin mod
  assets/vortexcraft/     -> model, blockstate, lang (thiếu texture PNG - xem trên)
  data/vortexcraft/       -> loot table, recipe
  data/minecraft/tags/    -> gắn tag mineable/pickaxe + needs_iron_tool cho ore
```

## Ý tưởng mở rộng thêm (nếu muốn)

- Cho Vortex Staff giảm độ bền (durability) mỗi lần dùng thay vì chỉ cooldown.
- Thêm world generation để Void Crystal Ore tự sinh ra trong hang động/Nether.
- Thêm hiệu ứng ngược: giữ Shift + right-click để "đẩy" thay vì "hút".
