package com.example.vortexcraft.client;

import com.example.vortexcraft.VortexCraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

/**
 * Chỉ đăng ký ở phía CLIENT (nhờ value = Dist.CLIENT) - áp dụng độ rung màn
 * hình mỗi khi Vortex Staff tung chiêu, dựa vào ClientEffects.
 */
@Mod.EventBusSubscriber(modid = VortexCraft.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientEvents {

    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public static void onCameraSetup(EntityViewRenderEvent.CameraSetup event) {
        float power = ClientEffects.currentPower();
        if (power <= 0.0F) return;

        event.setYaw(event.getYaw() + (RANDOM.nextFloat() - 0.5F) * power);
        event.setPitch(event.getPitch() + (RANDOM.nextFloat() - 0.5F) * power * 0.6F);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            ClientEffects.tickDown();
        }
    }
}
