package com.example.vortexcraft.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockDisplayReader;
import net.minecraft.world.World;

import java.util.Random;

/**
 * Quặng đặc biệt: phát ra ánh sáng yếu và thi thoảng bắn ra hạt "vortex particle"
 * để gợi ý người chơi rằng nó không phải đá thường.
 */
public class VoidCrystalOreBlock extends Block {

    public VoidCrystalOreBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void animateTick(net.minecraft.block.BlockState state, World world, BlockPos pos, Random rand) {
        // Hiệu ứng hạt nhẹ nhàng toả ra từ khối quặng, tạo cảm giác "sống"
        if (rand.nextInt(6) == 0) {
            double x = pos.getX() + 0.5D + (rand.nextDouble() - 0.5D) * 0.6D;
            double y = pos.getY() + 0.7D + rand.nextDouble() * 0.3D;
            double z = pos.getZ() + 0.5D + (rand.nextDouble() - 0.5D) * 0.6D;
            world.addParticle(net.minecraft.particles.ParticleTypes.PORTAL, x, y, z, 0.0D, 0.02D, 0.0D);
        }
    }
}
