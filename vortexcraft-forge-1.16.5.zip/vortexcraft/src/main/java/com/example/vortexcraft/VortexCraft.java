package com.example.vortexcraft;

import com.example.vortexcraft.init.ModBlocks;
import com.example.vortexcraft.init.ModItemProperties;
import com.example.vortexcraft.init.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(VortexCraft.MOD_ID)
public class VortexCraft {

    public static final String MOD_ID = "vortexcraft";

    public VortexCraft() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.register();

        modEventBus.addListener(this::clientSetup);
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        // Chỉ chạy phía client: đăng ký model theo mức tiến hóa của Vortex Staff.
        ModItemProperties.register();
    }
}
