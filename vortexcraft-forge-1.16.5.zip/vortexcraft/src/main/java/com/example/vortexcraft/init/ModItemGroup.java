package com.example.vortexcraft.init;

import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public class ModItemGroup {

    public static final ItemGroup VORTEXCRAFT = new ItemGroup("vortexcraft") {
        @Override
        public ItemStack makeIcon() {
            return new ItemStack(ModItems.VORTEX_STAFF.get());
        }
    };
}
