package com.example.vortexcraft.init;

import com.example.vortexcraft.VortexCraft;
import com.example.vortexcraft.block.VoidCrystalOreBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, VortexCraft.MOD_ID);

    public static final RegistryObject<Block> VOID_CRYSTAL_ORE = BLOCKS.register("void_crystal_ore",
            () -> new VoidCrystalOreBlock(AbstractBlock.Properties.of(Material.STONE)
                    .requiresCorrectToolForDrops()
                    .strength(4.0F, 6.0F)
                    .lightLevel(state -> 7)));

    public static void registerBlockItems(DeferredRegister<Item> items) {
        items.register("void_crystal_ore", () -> new BlockItem(VOID_CRYSTAL_ORE.get(),
                new Item.Properties().tab(ModItemGroup.VORTEXCRAFT)));
    }
}
