package com.example.vortexcraft.event;

import com.example.vortexcraft.VortexCraft;
import com.example.vortexcraft.item.VortexStaffItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Theo dõi số quái bị hạ (để tiến hóa) + chạy các hiệu ứng "sống" mỗi tick
 * của Vortex Staff (Hố Đen đang hoạt động, Vệ Tinh Hộ Vệ passive).
 */
@Mod.EventBusSubscriber(modid = VortexCraft.MOD_ID)
public class VortexStaffEvents {

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level.isClientSide) return;
        if (event.getEntity() instanceof PlayerEntity) return;

        Entity source = event.getSource().getEntity();
        if (!(source instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) source;

        ItemStack held = player.getMainHandItem();
        if (held.getItem() instanceof VortexStaffItem) {
            VortexStaffItem.addKill(held, player);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        PlayerEntity player = event.player;
        if (player.level.isClientSide) return;

        for (Hand hand : Hand.values()) {
            ItemStack stack = player.getItemInHand(hand);
            if (!(stack.getItem() instanceof VortexStaffItem)) continue;
            VortexStaffItem.tickBlackHole(stack, player);
            VortexStaffItem.tickSatellites(stack, player);
            VortexStaffItem.tickJudgement(stack, player);
        }
    }
}
