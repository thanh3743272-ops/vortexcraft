package com.example.vortexcraft.event;

import com.example.vortexcraft.VortexCraft;
import com.example.vortexcraft.item.VortexStaffItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Theo dõi số quái bị hạ trong lúc người chơi đang cầm Vortex Staff ở tay chính,
 * để tích lũy điểm tiến hóa cho chính cây gậy đó (lưu trong NBT của ItemStack).
 */
@Mod.EventBusSubscriber(modid = VortexCraft.MOD_ID)
public class VortexStaffEvents {

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level.isClientSide) return;
        if (event.getEntity() instanceof PlayerEntity) return; // không tính giết người chơi khác

        Entity source = event.getSource().getEntity();
        if (!(source instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) source;

        ItemStack held = player.getMainHandItem();
        if (held.getItem() instanceof VortexStaffItem) {
            VortexStaffItem.addKill(held, player);
        }
    }
}
