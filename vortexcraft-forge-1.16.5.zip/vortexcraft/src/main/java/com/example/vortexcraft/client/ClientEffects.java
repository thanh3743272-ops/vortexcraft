package com.example.vortexcraft.client;

/**
 * Lưu trạng thái rung màn hình hiện tại (chỉ dùng ở client). Đơn giản, không
 * cần gói tin mạng vì hàm releaseUsing trong VortexStaffItem đã chạy song song
 * ở cả server lẫn client (client tự dự đoán), nên gọi trigger ngay tại nhánh
 * client của releaseUsing là đủ, không cần đồng bộ qua network.
 */
public class ClientEffects {

    private static int shakeTicksLeft = 0;
    private static float shakeIntensity = 0.0F;

    public static void triggerShake(int ticks, float intensity) {
        // Nếu đang rung rồi thì lấy giá trị mạnh hơn, không cộng dồn linh tinh.
        if (intensity > shakeIntensity || ticks > shakeTicksLeft) {
            shakeTicksLeft = Math.max(shakeTicksLeft, ticks);
            shakeIntensity = Math.max(shakeIntensity, intensity);
        }
    }

    public static void tickDown() {
        if (shakeTicksLeft > 0) shakeTicksLeft--;
        else shakeIntensity = 0.0F;
    }

    public static float currentPower() {
        if (shakeTicksLeft <= 0) return 0.0F;
        return shakeIntensity * (shakeTicksLeft / 10.0F);
    }
}
