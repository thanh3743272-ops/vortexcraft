package com.example.vortexcraft.init;

import com.example.vortexcraft.VortexCraft;
import com.example.vortexcraft.item.VortexStaffItem;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, VortexCraft.MOD_ID);

    public static final RegistryObject<Item> VORTEX_STAFF = ITEMS.register("vortex_staff",
            () -> new VortexStaffItem(new Item.Properties()
                    .tab(ModItemGroup.VORTEXCRAFT)
                    .stacksTo(1)
                    .durability(64)));

    public static final RegistryObject<Item> VOID_CRYSTAL = ITEMS.register("void_crystal",
            () -> new Item(new Item.Properties().tab(ModItemGroup.VORTEXCRAFT)));

    public static void register() {
        ModBlocks.registerBlockItems(ITEMS);
    }
}
