package com.example.vortexcraft.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

import java.util.List;

/**
 * Vortex Staff: khi dùng, hút tất cả sinh vật và item xung quanh (bán kính 8 khối)
 * lại gần người chơi, giống một máy hút bụi phép thuật.
 * Hữu ích để gom item rơi rải rác hoặc kéo mob lại gần để combat/farm.
 */
public class VortexStaffItem extends Item {

    private static final double RADIUS = 8.0D;
    private static final int COOLDOWN_TICKS = 100; // 5 giây

    public VortexStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!world.isClientSide) {
            AxisAlignedBB area = player.getBoundingBox().inflate(RADIUS);
            List<Entity> nearby = world.getEntities(player, area,
                    e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

            for (Entity entity : nearby) {
                Vector3d toPlayer = player.position().subtract(entity.position());
                double distance = toPlayer.length();
                if (distance < 0.1D) continue;

                Vector3d direction = toPlayer.normalize();
                double strength = Math.min(1.0D, distance / RADIUS) * 0.75D;

                entity.setDeltaMovement(entity.getDeltaMovement()
                        .add(direction.x * strength, direction.y * strength * 0.4D, direction.z * strength));
                entity.hurtMarked = true;
            }

            world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON,
                    SoundCategory.PLAYERS, 1.0F, 1.4F);

            player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        }

        player.swing(hand);
        return ActionResult.sidedSuccess(stack, world.isClientSide);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 0;
    }
}
