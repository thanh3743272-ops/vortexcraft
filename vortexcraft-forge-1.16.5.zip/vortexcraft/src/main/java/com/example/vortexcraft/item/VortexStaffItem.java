package com.example.vortexcraft.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.block.BlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.projectile.AbstractArrowEntity;
import net.minecraft.entity.projectile.DamagingProjectileEntity;
import net.minecraft.entity.projectile.ProjectileItemEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Vortex Staff - TỰ TIẾN HÓA theo số quái bị hạ khi cầm nó. 5 giai đoạn, mỗi
 * giai đoạn đổi tên + texture + mạnh hơn. Có nhiều chiêu dựa vào tổ hợp thao tác:
 *
 *  - Bấm nhanh chuột phải (không Shift)   -> Khiên Phản
 *  - Giữ chuột phải, thả ra (không Shift) -> Hút Xoáy (giữ TỐI ĐA -> Hố Đen)
 *  - Bấm nhanh + Shift                    -> Chớp Dịch Chuyển
 *  - Giữ + Shift, thả ra                  -> Tia Năng Lượng
 *  - Đánh thường (chuột trái)             -> Chém Xuyên (cleave)
 *  - Passive từ cấp 3                     -> Vệ Tinh Hộ Vệ (tự động tấn công quái gần nhất)
 */
public class VortexStaffItem extends Item {

    private static final int[] KILL_THRESHOLDS = {0, 10, 30, 60, 100};
    private static final String[] STAGE_NAMES = {
            "Gậy Xoáy Thô Sơ",
            "Gậy Xoáy Thức Tỉnh",
            "Trượng Xoáy Tinh Luyện",
            "Trượng Xoáy Cổ Đại",
            "Trượng Hư Không Tối Thượng"
    };

    private static final double[] PULL_RADIUS      = {8.0, 9.0, 10.0, 11.5, 13.0};
    private static final double[] LAUNCH_MULT      = {1.0, 1.15, 1.3, 1.5, 1.8};
    private static final double[] BEAM_RANGE       = {14.0, 16.0, 18.0, 20.0, 24.0};
    private static final float[] BEAM_MAX_HARDNESS = {1.0F, 1.0F, 1.5F, 2.0F, 3.0F};
    private static final float[] BEAM_DAMAGE_BONUS = {8.0F, 10.0F, 13.0F, 16.0F, 20.0F};
    private static final int[] COOLDOWN_TICKS      = {60, 55, 50, 45, 35};

    private static final double ANCHOR_DISTANCE = 4.0D;
    private static final double ORBIT_RADIUS = 1.4D;
    private static final int MAX_CHARGE_TICKS = 40;
    private static final int QUICK_TAP_THRESHOLD = 5;
    private static final double BEAM_STEP = 0.4D;

    private static final UUID ATTACK_DAMAGE_UUID = UUID.fromString("52d17e4b-c86d-4fca-8f5e-6f8f9c2f1a10");
    private static final UUID ATTACK_SPEED_UUID = UUID.fromString("52d17e4b-c86d-4fca-8f5e-6f8f9c2f1a11");
    private final Multimap<Attribute, AttributeModifier> attributeModifiers;

    public VortexStaffItem(Properties properties) {
        super(properties);
        ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(ATTACK_DAMAGE_UUID, "Weapon modifier", 4.0D, AttributeModifier.Operation.ADDITION));
        builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(ATTACK_SPEED_UUID, "Weapon modifier", -2.0D, AttributeModifier.Operation.ADDITION));
        this.attributeModifiers = builder.build();
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.MAINHAND ? this.attributeModifiers : super.getDefaultAttributeModifiers(slot);
    }

    // ================= HỆ THỐNG TIẾN HÓA =================

    public static int getKills(ItemStack stack) {
        return stack.hasTag() ? stack.getTag().getInt("kills") : 0;
    }

    public static int getStage(ItemStack stack) {
        int kills = getKills(stack);
        int stage = 0;
        for (int i = 0; i < KILL_THRESHOLDS.length; i++) {
            if (kills >= KILL_THRESHOLDS[i]) stage = i;
        }
        return stage;
    }

    public static void addKill(ItemStack stack, PlayerEntity player) {
        int before = getStage(stack);
        int kills = getKills(stack) + 1;
        stack.getOrCreateTag().putInt("kills", kills);
        int after = getStage(stack);
        if (after > before) {
            player.sendMessage(new StringTextComponent("✦ Trượng của bạn đã tiến hóa thành: ")
                    .append(new StringTextComponent(STAGE_NAMES[after]).withStyle(TextFormatting.LIGHT_PURPLE)),
                    player.getUUID());
            player.level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                    SoundCategory.PLAYERS, 1.0F, 1.0F);
        }
    }

    @Override
    public ITextComponent getName(ItemStack stack) {
        return new StringTextComponent(STAGE_NAMES[getStage(stack)]);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        int stage = getStage(stack);
        int kills = getKills(stack);
        tooltip.add(new StringTextComponent("Quái đã hạ: " + kills).withStyle(TextFormatting.GRAY));
        if (stage < KILL_THRESHOLDS.length - 1) {
            int next = KILL_THRESHOLDS[stage + 1];
            tooltip.add(new StringTextComponent("Tiến hóa tiếp theo (" + STAGE_NAMES[stage + 1] + "): "
                    + kills + "/" + next).withStyle(TextFormatting.DARK_PURPLE));
        } else {
            tooltip.add(new StringTextComponent("Đã đạt cấp tiến hóa tối đa!").withStyle(TextFormatting.GOLD));
        }
        tooltip.add(new StringTextComponent("Bấm nhanh: Khiên Phản | Giữ: Hút Xoáy (đầy: Hố Đen)")
                .withStyle(TextFormatting.DARK_GRAY));
        tooltip.add(new StringTextComponent("Shift+bấm nhanh: Chớp Dịch Chuyển | Shift+giữ: Tia Năng Lượng")
                .withStyle(TextFormatting.DARK_GRAY));
        tooltip.add(new StringTextComponent("Đánh thường: Chém Xuyên").withStyle(TextFormatting.DARK_GRAY));
        if (stage >= 3) {
            tooltip.add(new StringTextComponent("Passive: Vệ Tinh Hộ Vệ đang hoạt động").withStyle(TextFormatting.AQUA));
        }
    }

    // ================= CHÉM XUYÊN (đánh thường) =================

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof PlayerEntity && !target.level.isClientSide) {
            cleaveNearby((PlayerEntity) attacker, target, getStage(stack));
        }
        stack.hurtAndBreak(1, attacker, e -> e.broadcastBreakEvent(EquipmentSlotType.MAINHAND));
        return true;
    }

    private void cleaveNearby(PlayerEntity player, LivingEntity primaryTarget, int stage) {
        World world = player.level;
        double radius = 2.5D + stage * 0.3D;
        AxisAlignedBB area = primaryTarget.getBoundingBox().inflate(radius);
        Vector3d look = player.getLookAngle();
        int i = 0;
        for (Entity e : world.getEntities(player, area,
                en -> en instanceof LivingEntity && en != primaryTarget && en != player)) {
            LivingEntity le = (LivingEntity) e;
            le.hurt(DamageSource.playerAttack(player), 2.0F + stage * 1.0F);
            double side = (i % 2 == 0) ? 1.0D : -1.0D;
            Vector3d sideways = new Vector3d(-look.z, 0.15D, look.x).scale(side * 0.5D);
            le.setDeltaMovement(le.getDeltaMovement().add(sideways));
            i++;
        }
    }

    // ================= SỬ DỤNG (chuột phải) =================

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getItemInHand(hand);
        stack.getOrCreateTag().putBoolean("beamMode", player.isShiftKeyDown());
        player.startUsingItem(hand);
        return ActionResult.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAction getUseAnimation(ItemStack stack) {
        return UseAction.SPEAR;
    }

    private boolean isBeamMode(ItemStack stack) {
        return stack.hasTag() && stack.getTag().getBoolean("beamMode");
    }

    @Override
    public void onUsingTick(ItemStack stack, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;
        World world = player.level;
        int chargeTicks = Math.min(this.getUseDuration(stack) - remainingUseTicks, MAX_CHARGE_TICKS);
        int stage = getStage(stack);

        if (isBeamMode(stack)) {
            tickBeamCharge(world, player, chargeTicks);
        } else {
            tickVortexPull(world, player, chargeTicks, stage);
        }
    }

    // ================= CHẾ ĐỘ HÚT XOÁY =================

    private void tickVortexPull(World world, PlayerEntity player, int chargeTicks, int stage) {
        Vector3d look = player.getLookAngle();
        Vector3d anchor = player.getEyePosition(1.0F).add(look.scale(ANCHOR_DISTANCE));
        double pullRadius = PULL_RADIUS[stage];

        if (!world.isClientSide) {
            AxisAlignedBB area = player.getBoundingBox().inflate(pullRadius);
            List<Entity> nearby = world.getEntities(player, area,
                    e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

            for (Entity entity : nearby) {
                Vector3d toAnchor = anchor.subtract(entity.position().add(0, entity.getBbHeight() * 0.5D, 0));
                double distance = toAnchor.length();
                if (distance < 0.05D) continue;

                if (distance <= ORBIT_RADIUS + 0.6D) {
                    Vector3d radial = entity.position().subtract(anchor);
                    Vector3d tangent = new Vector3d(-radial.z, 0, radial.x);
                    if (tangent.lengthSqr() > 0.0001D) tangent = tangent.normalize();

                    double spin = 0.10D + (chargeTicks * 0.003D);
                    double inward = (distance - ORBIT_RADIUS) * 0.15D;
                    double dampen = 0.55D;

                    entity.setDeltaMovement(entity.getDeltaMovement().scale(dampen)
                            .add(tangent.x * spin + toAnchor.normalize().x * inward,
                                 toAnchor.y * 0.06D,
                                 tangent.z * spin + toAnchor.normalize().z * inward));
                } else {
                    double strength = Math.min(1.0D, distance / pullRadius) * 0.85D;
                    Vector3d dir = toAnchor.normalize();
                    entity.setDeltaMovement(entity.getDeltaMovement()
                            .add(dir.x * strength, dir.y * strength * 0.5D, dir.z * strength));
                }
                entity.hurtMarked = true;
                entity.fallDistance = 0.0F;
            }

            if (chargeTicks % 10 == 0) {
                world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON,
                        SoundCategory.PLAYERS, 0.4F, 1.6F);
            }
        } else if (chargeTicks % 2 == 0) {
            world.addParticle(ParticleTypes.PORTAL, anchor.x, anchor.y, anchor.z, 0, 0, 0);
        }
    }

    // ================= CHẾ ĐỘ TIA NĂNG LƯỢNG =================

    private void tickBeamCharge(World world, PlayerEntity player, int chargeTicks) {
        Vector3d tip = player.getEyePosition(1.0F).add(player.getLookAngle().scale(1.3D));
        if (world.isClientSide) {
            int density = 1 + chargeTicks / 6;
            for (int i = 0; i < density; i++) {
                world.addParticle(ParticleTypes.END_ROD, tip.x, tip.y, tip.z,
                        (world.random.nextDouble() - 0.5D) * 0.05D,
                        (world.random.nextDouble() - 0.5D) * 0.05D,
                        (world.random.nextDouble() - 0.5D) * 0.05D);
            }
        } else if (chargeTicks % 8 == 0) {
            world.playSound(null, player.blockPosition(), SoundEvents.BEACON_AMBIENT,
                    SoundCategory.PLAYERS, 0.3F, 1.0F + chargeTicks * 0.02F);
        }
    }

    // ================= BUÔNG RA -> CHỌN CHIÊU =================

    @Override
    public void releaseUsing(ItemStack stack, World world, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;

        int chargeTicks = Math.min(this.getUseDuration(stack) - remainingUseTicks, MAX_CHARGE_TICKS);
        boolean beamMode = isBeamMode(stack);
        boolean quickTap = chargeTicks < QUICK_TAP_THRESHOLD;
        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS;

        if (world.isClientSide) {
            float intensity;
            int duration;
            if (beamMode) {
                intensity = quickTap ? 3.0F : 4.0F + chargePercent * 5.0F;
                duration = quickTap ? 4 : 8;
            } else if (quickTap) {
                intensity = 3.0F;
                duration = 5;
            } else if (chargePercent >= 0.999F) {
                intensity = 10.0F; // Hố Đen - chiêu mạnh nhất, rung nhiều nhất
                duration = 14;
            } else {
                intensity = 2.0F + chargePercent * 4.0F;
                duration = 6;
            }
            com.example.vortexcraft.client.ClientEffects.triggerShake(duration, intensity);
            return;
        }

        int stage = getStage(stack);
        if (beamMode) {
            if (quickTap) blinkStrike(world, player, stage);
            else fireBeam(world, player, chargeTicks, stage);
        } else {
            if (quickTap) shieldPulse(world, player, stage);
            else launchVortex(stack, world, player, chargeTicks, stage);
        }

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS[stage]);
        player.swing(player.getUsedItemHand());
    }

    // ================= KHIÊN PHẢN =================

    private void shieldPulse(World world, PlayerEntity player, int stage) {
        double radius = 4.0D + stage * 0.5D;
        AxisAlignedBB area = player.getBoundingBox().inflate(radius);

        for (Entity e : world.getEntities(player, area, en ->
                en instanceof ProjectileItemEntity || en instanceof AbstractArrowEntity || en instanceof DamagingProjectileEntity)) {
            e.remove();
        }
        for (Entity e : world.getEntities(player, area, en -> en instanceof LivingEntity)) {
            Vector3d away = e.position().subtract(player.position());
            Vector3d dir = away.lengthSqr() > 0.01D ? away.normalize() : new Vector3d(0, 0, 1);
            e.setDeltaMovement(e.getDeltaMovement().add(dir.x * 0.6D, 0.2D, dir.z * 0.6D));
        }
        player.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 20 + stage * 5, 1));

        if (world instanceof ServerWorld) {
            ((ServerWorld) world).sendParticles(ParticleTypes.END_ROD,
                    player.getX(), player.getY() + 1.0D, player.getZ(), 20, 0.6, 0.6, 0.6, 0.02);
        }
        world.playSound(null, player.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundCategory.PLAYERS, 1.0F, 1.2F);
    }

    // ================= CHỚP DỊCH CHUYỂN =================

    private void blinkStrike(World world, PlayerEntity player, int stage) {
        double maxDist = 5.0D + stage * 1.0D;
        Vector3d start = player.position();
        Vector3d look = player.getLookAngle();
        Vector3d dest = start;

        double traveled = 0.0D;
        while (traveled < maxDist) {
            Vector3d next = start.add(look.scale(traveled + 0.5D));
            BlockPos pos = new BlockPos(next);
            if (!world.isEmptyBlock(pos) || !world.isEmptyBlock(pos.above())) break;
            dest = next;
            traveled += 0.5D;
        }

        if (player instanceof ServerPlayerEntity) {
            ServerPlayerEntity sp = (ServerPlayerEntity) player;
            sp.connection.teleport(dest.x, dest.y, dest.z, sp.yRot, sp.xRot);
        }

        AxisAlignedBB area = player.getBoundingBox().inflate(2.5D);
        for (Entity e : world.getEntities(player, area, en -> en instanceof LivingEntity)) {
            Vector3d away = e.position().subtract(player.position());
            Vector3d dir = away.lengthSqr() > 0.01D ? away.normalize() : look;
            e.setDeltaMovement(e.getDeltaMovement().add(dir.x * 0.5D, 0.2D, dir.z * 0.5D));
            ((LivingEntity) e).hurt(DamageSource.playerAttack(player), 2.0F + stage);
        }

        if (world instanceof ServerWorld) {
            ((ServerWorld) world).sendParticles(ParticleTypes.REVERSE_PORTAL,
                    dest.x, dest.y + 1.0D, dest.z, 30, 0.4, 0.6, 0.4, 0.05);
        }
        world.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    // ================= HÚT XOÁY (buông ra) + HỐ ĐEN ở mức sạc đầy =================

    private void launchVortex(ItemStack stack, World world, PlayerEntity player, int chargeTicks, int stage) {
        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS;

        if (chargePercent >= 0.999F) {
            activateBlackHole(stack, world, player, stage);
            return;
        }

        double launchStrength = (0.8D + chargePercent * 2.2D) * LAUNCH_MULT[stage];
        double pullRadius = PULL_RADIUS[stage];

        AxisAlignedBB area = player.getBoundingBox().inflate(pullRadius);
        List<Entity> nearby = world.getEntities(player, area,
                e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

        Vector3d look = player.getLookAngle();
        for (Entity entity : nearby) {
            Vector3d away = entity.position().subtract(player.position());
            double dist = away.length();
            Vector3d direction = dist < 0.1D ? look : away.normalize();

            entity.setDeltaMovement(direction.x * launchStrength,
                    0.25D + chargePercent * 0.35D, direction.z * launchStrength);
            entity.hurtMarked = true;
        }

        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.0F, 0.8F + chargePercent * 0.6F);
    }

    private void activateBlackHole(ItemStack stack, World world, PlayerEntity player, int stage) {
        Vector3d anchor = player.getEyePosition(1.0F).add(player.getLookAngle().scale(ANCHOR_DISTANCE));
        CompoundNBT tag = stack.getOrCreateTag();
        tag.putDouble("bhX", anchor.x);
        tag.putDouble("bhY", anchor.y);
        tag.putDouble("bhZ", anchor.z);
        tag.putInt("bhTicks", 100 + stage * 20);
        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.5F, 0.4F);
    }

    /** Gọi mỗi tick từ VortexStaffEvents nếu người chơi đang cầm cây này và Hố Đen đang hoạt động. */
    public static void tickBlackHole(ItemStack stack, PlayerEntity player) {
        if (!stack.hasTag()) return;
        CompoundNBT tag = stack.getTag();
        int ticks = tag.getInt("bhTicks");
        if (ticks <= 0) return;

        World world = player.level;
        Vector3d anchor = new Vector3d(tag.getDouble("bhX"), tag.getDouble("bhY"), tag.getDouble("bhZ"));
        AxisAlignedBB area = new AxisAlignedBB(anchor.x - 10, anchor.y - 10, anchor.z - 10,
                anchor.x + 10, anchor.y + 10, anchor.z + 10);

        for (Entity e : world.getEntities(null, area,
                en -> (en instanceof LivingEntity && en != player) || en instanceof ItemEntity)) {
            Vector3d toAnchor = anchor.subtract(e.position());
            double d = toAnchor.length();
            if (d < 0.3D) continue;
            Vector3d dir = toAnchor.normalize();
            double strength = Math.min(1.0D, d / 10.0D) * 0.5D;
            e.setDeltaMovement(e.getDeltaMovement().add(dir.x * strength, dir.y * strength * 0.5D, dir.z * strength));
            e.fallDistance = 0.0F;
        }

        if (world instanceof ServerWorld) {
            ((ServerWorld) world).sendParticles(ParticleTypes.PORTAL,
                    anchor.x, anchor.y, anchor.z, 6, 0.5, 0.5, 0.5, 0.02);
        }

        ticks--;
        if (ticks <= 0) {
            for (Entity e : world.getEntities(null, area, en -> en instanceof LivingEntity && en != player)) {
                Vector3d away = e.position().subtract(anchor);
                Vector3d dir = away.lengthSqr() > 0.01D ? away.normalize() : new Vector3d(0, 1, 0);
                e.setDeltaMovement(dir.x * 2.0D, 0.5D, dir.z * 2.0D);
                ((LivingEntity) e).hurt(DamageSource.playerAttack(player), 6.0F);
            }
            if (world instanceof ServerWorld) {
                ((ServerWorld) world).sendParticles(ParticleTypes.EXPLOSION,
                        anchor.x, anchor.y, anchor.z, 3, 0.3, 0.3, 0.3, 0.0);
            }
            world.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE,
                    SoundCategory.PLAYERS, 1.5F, 0.7F);
            tag.remove("bhTicks");
        } else {
            tag.putInt("bhTicks", ticks);
        }
    }

    // ================= VỆ TINH HỘ VỆ (passive, từ cấp 3) =================

    /** Gọi mỗi tick từ VortexStaffEvents nếu người chơi đang cầm cây này. */
    public static void tickSatellites(ItemStack stack, PlayerEntity player) {
        int stage = getStage(stack);
        if (stage < 3) return;

        CompoundNBT tag = stack.getOrCreateTag();
        int cd = tag.getInt("satCooldown");
        if (cd > 0) {
            tag.putInt("satCooldown", cd - 1);
            return;
        }

        World world = player.level;
        double radius = 6.0D;
        AxisAlignedBB area = player.getBoundingBox().inflate(radius);
        Entity target = null;
        double best = Double.MAX_VALUE;
        for (Entity e : world.getEntities(player, area, en -> en instanceof MonsterEntity)) {
            double d = e.distanceToSqr(player);
            if (d < best) { best = d; target = e; }
        }

        if (target != null) {
            ((LivingEntity) target).hurt(DamageSource.playerAttack(player), 2.0F);
            if (world instanceof ServerWorld) {
                ((ServerWorld) world).sendParticles(ParticleTypes.END_ROD,
                        target.getX(), target.getY() + 0.5D, target.getZ(), 6, 0.15, 0.15, 0.15, 0.02);
            }
            world.playSound(null, player.blockPosition(), SoundEvents.ARROW_HIT, SoundCategory.PLAYERS, 0.4F, 1.8F);
        }
        tag.putInt("satCooldown", 40);
    }

    // ================= TIA NĂNG LƯỢNG (buông ra) =================

    private void fireBeam(World world, PlayerEntity player, int chargeTicks, int stage) {
        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS;
        float damage = 2.0F + chargePercent * BEAM_DAMAGE_BONUS[stage];
        double knockback = 0.4D + chargePercent * 0.6D;
        double range = BEAM_RANGE[stage];
        float maxHardness = BEAM_MAX_HARDNESS[stage];

        Vector3d start = player.getEyePosition(1.0F);
        Vector3d mainLook = player.getLookAngle();

        shootSingleBeam(world, player, start, mainLook, range, maxHardness, damage, knockback);

        if (stage >= 4) {
            double angle = Math.toRadians(15.0D);
            double cos = Math.cos(angle), sin = Math.sin(angle);
            Vector3d sideLook = new Vector3d(
                    mainLook.x * cos - mainLook.z * sin,
                    mainLook.y,
                    mainLook.x * sin + mainLook.z * cos
            ).normalize();
            shootSingleBeam(world, player, start, sideLook, range * 0.8D, maxHardness, damage * 0.6F, knockback * 0.7D);
        }

        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.2F, 0.6F + chargePercent * 0.4F);
    }

    private void shootSingleBeam(World world, PlayerEntity player, Vector3d start, Vector3d look,
                                  double range, float maxHardness, float damage, double knockback) {
        Set<BlockPos> processedBlocks = new HashSet<>();
        Set<Entity> hitEntities = new HashSet<>();

        double traveled = 0.0D;
        while (traveled < range) {
            Vector3d point = start.add(look.scale(traveled));
            BlockPos pos = new BlockPos(point);

            if (processedBlocks.add(pos)) {
                BlockState state = world.getBlockState(pos);
                if (!state.isAir(world, pos)) {
                    float hardness = state.getDestroySpeed(world, pos);
                    if (hardness < 0F || hardness > maxHardness) break;
                    world.destroyBlock(pos, true);
                }
            }

            AxisAlignedBB hitBox = new AxisAlignedBB(point.x - 0.6, point.y - 0.6, point.z - 0.6,
                    point.x + 0.6, point.y + 0.6, point.z + 0.6);
            for (Entity entity : world.getEntities(player, hitBox,
                    e -> e != player && e instanceof LivingEntity)) {
                if (hitEntities.add(entity)) {
                    entity.hurt(DamageSource.playerAttack(player), damage);
                    entity.setDeltaMovement(entity.getDeltaMovement().add(
                            look.x * knockback, 0.15D, look.z * knockback));
                    entity.setSecondsOnFire(3);
                }
            }

            traveled += BEAM_STEP;
        }

        if (world instanceof ServerWorld) {
            for (double d = 0; d < traveled; d += 0.3D) {
                Vector3d p = start.add(look.scale(d));
                ((ServerWorld) world).sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0, 0, 0, 0.0D);
            }
        }
    }
}
