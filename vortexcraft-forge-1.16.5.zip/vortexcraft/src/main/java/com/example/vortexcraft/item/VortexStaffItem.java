package com.example.vortexcraft.item;

import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

import java.util.List;

/**
 * Vortex Staff v3.
 *
 * CHẾ ĐỘ 1 - Hút xoáy (giữ chuột phải bình thường, không giữ Shift):
 *   Hút mob/item lại gần rồi cho chúng lơ lửng, XOAY TRÒN thành 1 cụm nhỏ ngay
 *   phía trước mặt (cách mắt ~4 khối, ngang tầm nhìn) - không dính sát người nên
 *   không che tầm nhìn. Buông ra để phóng văng chúng ra xa theo hướng đang nhìn.
 *
 * CHẾ ĐỘ 2 - Tia năng lượng (giữ Shift + giữ chuột phải):
 *   Đầu gậy sáng dần lên khi sạc. Buông ra bắn 1 tia thẳng về phía trước, xuyên
 *   phá các khối mềm (đất, cát, kính, lá, len...) trên đường đi, gây sát thương
 *   vừa phải + đẩy lùi + đốt nhẹ sinh vật trúng tia. Sạc càng lâu càng mạnh.
 */
public class VortexStaffItem extends Item {

    // --- Chế độ hút xoáy ---
    private static final double PULL_RADIUS = 8.0D;
    private static final double ANCHOR_DISTANCE = 4.0D;   // cụm xoáy cách mắt bao xa
    private static final double ORBIT_RADIUS = 1.4D;      // bán kính vòng xoay quanh tâm cụm
    private static final int MAX_CHARGE_TICKS = 40;       // 2 giây giữ = sạc tối đa
    private static final int COOLDOWN_TICKS = 60;

    // --- Chế độ tia năng lượng ---
    private static final double BEAM_RANGE = 14.0D;
    private static final float BEAM_MAX_HARDNESS = 1.0F;  // chỉ phá được khối "mềm" (không phá đá/gỗ)
    private static final double BEAM_STEP = 0.4D;

    public VortexStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getItemInHand(hand);
        // Ghi nhớ ngay lúc bắt đầu giữ: có đang cúi (Shift) hay không => chọn chế độ.
        stack.getOrCreateTag().putBoolean("beamMode", player.isShiftKeyDown());
        player.startUsingItem(hand);
        return ActionResult.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAction getUseAnimation(ItemStack stack) {
        return UseAction.SPEAR;
    }

    private boolean isBeamMode(ItemStack stack) {
        return stack.hasTag() && stack.getTag().getBoolean("beamMode");
    }

    @Override
    public void onUsingTick(ItemStack stack, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;
        World world = player.level;
        int chargeTicks = Math.min(this.getUseDuration(stack) - remainingUseTicks, MAX_CHARGE_TICKS);

        if (isBeamMode(stack)) {
            tickBeamCharge(world, player, chargeTicks);
        } else {
            tickVortexPull(world, player, chargeTicks);
        }
    }

    // ================= CHẾ ĐỘ HÚT XOÁY =================

    private void tickVortexPull(World world, PlayerEntity player, int chargeTicks) {
        Vector3d look = player.getLookAngle();
        Vector3d anchor = player.getEyePosition(1.0F).add(look.scale(ANCHOR_DISTANCE));

        if (!world.isClientSide) {
            AxisAlignedBB area = player.getBoundingBox().inflate(PULL_RADIUS);
            List<Entity> nearby = world.getEntities(player, area,
                    e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

            for (Entity entity : nearby) {
                Vector3d toAnchor = anchor.subtract(entity.position().add(0, entity.getBbHeight() * 0.5D, 0));
                double distance = toAnchor.length();
                if (distance < 0.05D) continue;

                if (distance <= ORBIT_RADIUS + 0.6D) {
                    // Đã vào cụm: cho xoay tròn nhẹ quanh tâm thay vì đứng yên cứng.
                    Vector3d radial = entity.position().subtract(anchor);
                    Vector3d tangent = new Vector3d(-radial.z, 0, radial.x);
                    if (tangent.lengthSqr() > 0.0001D) tangent = tangent.normalize();

                    double spin = 0.10D + (chargeTicks * 0.003D);
                    double inward = (distance - ORBIT_RADIUS) * 0.15D;
                    double dampen = 0.55D;

                    entity.setDeltaMovement(entity.getDeltaMovement().scale(dampen)
                            .add(tangent.x * spin + toAnchor.normalize().x * inward,
                                 toAnchor.y * 0.06D,
                                 tangent.z * spin + toAnchor.normalize().z * inward));
                } else {
                    double strength = Math.min(1.0D, distance / PULL_RADIUS) * 0.85D;
                    Vector3d dir = toAnchor.normalize();
                    entity.setDeltaMovement(entity.getDeltaMovement()
                            .add(dir.x * strength, dir.y * strength * 0.5D, dir.z * strength));
                }
                entity.hurtMarked = true;
                entity.fallDistance = 0.0F;
            }

            if (chargeTicks % 10 == 0) {
                world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON,
                        SoundCategory.PLAYERS, 0.4F, 1.6F);
            }
        } else if (chargeTicks % 2 == 0) {
            world.addParticle(ParticleTypes.PORTAL, anchor.x, anchor.y, anchor.z, 0, 0, 0);
        }
    }

    // ================= CHẾ ĐỘ TIA NĂNG LƯỢNG =================

    private void tickBeamCharge(World world, PlayerEntity player, int chargeTicks) {
        Vector3d tip = player.getEyePosition(1.0F).add(player.getLookAngle().scale(1.3D));
        if (world.isClientSide) {
            int density = 1 + chargeTicks / 6; // càng sạc lâu càng nhiều hạt sáng ở đầu gậy
            for (int i = 0; i < density; i++) {
                world.addParticle(ParticleTypes.END_ROD, tip.x, tip.y, tip.z,
                        (world.random.nextDouble() - 0.5D) * 0.05D,
                        (world.random.nextDouble() - 0.5D) * 0.05D,
                        (world.random.nextDouble() - 0.5D) * 0.05D);
            }
        } else if (chargeTicks % 8 == 0) {
            world.playSound(null, player.blockPosition(), SoundEvents.BEACON_AMBIENT,
                    SoundCategory.PLAYERS, 0.3F, 1.0F + chargeTicks * 0.02F);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, World world, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;
        if (world.isClientSide) return;

        int chargeTicks = Math.min(this.getUseDuration(stack) - remainingUseTicks, MAX_CHARGE_TICKS);
        boolean beamMode = isBeamMode(stack);

        if (beamMode) {
            if (chargeTicks >= 2) fireBeam(world, player, chargeTicks);
        } else {
            if (chargeTicks >= 2) launchVortex(world, player, chargeTicks);
        }

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        player.swing(player.getUsedItemHand());
    }

    private void launchVortex(World world, PlayerEntity player, int chargeTicks) {
        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS;
        double launchStrength = 0.8D + chargePercent * 2.2D;

        AxisAlignedBB area = player.getBoundingBox().inflate(PULL_RADIUS);
        List<Entity> nearby = world.getEntities(player, area,
                e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

        Vector3d look = player.getLookAngle();
        for (Entity entity : nearby) {
            Vector3d away = entity.position().subtract(player.position());
            double dist = away.length();
            Vector3d direction = dist < 0.1D ? look : away.normalize();

            entity.setDeltaMovement(direction.x * launchStrength,
                    0.25D + chargePercent * 0.35D, direction.z * launchStrength);
            entity.hurtMarked = true;
        }

        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.0F, 0.8F + chargePercent * 0.6F);
    }

    private void fireBeam(World world, PlayerEntity player, int chargeTicks) {
        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS;
        float damage = 2.0F + chargePercent * 8.0F; // tối đa 10 sát thương (~5 tim)
        double knockback = 0.4D + chargePercent * 0.6D;

        Vector3d start = player.getEyePosition(1.0F);
        Vector3d look = player.getLookAngle();

        java.util.Set<BlockPos> processedBlocks = new java.util.HashSet<>();
        java.util.Set<Entity> hitEntities = new java.util.HashSet<>();

        double traveled = 0.0D;
        while (traveled < BEAM_RANGE) {
            Vector3d point = start.add(look.scale(traveled));
            BlockPos pos = new BlockPos(point);

            if (processedBlocks.add(pos)) {
                BlockState state = world.getBlockState(pos);
                if (!state.isAir(world, pos)) {
                    float hardness = state.getDestroySpeed(world, pos);
                    if (hardness < 0F || hardness > BEAM_MAX_HARDNESS) {
                        break; // gặp khối cứng -> tia bị chặn lại tại đây
                    }
                    world.destroyBlock(pos, true);
                }
            }

            AxisAlignedBB hitBox = new AxisAlignedBB(point.x - 0.6, point.y - 0.6, point.z - 0.6,
                    point.x + 0.6, point.y + 0.6, point.z + 0.6);
            for (Entity entity : world.getEntities(player, hitBox,
                    e -> e != player && e instanceof LivingEntity)) {
                if (hitEntities.add(entity)) {
                    entity.hurt(DamageSource.playerAttack(player), damage);
                    entity.setDeltaMovement(entity.getDeltaMovement().add(
                            look.x * knockback, 0.15D, look.z * knockback));
                    entity.setSecondsOnFire(3);
                }
            }

            traveled += BEAM_STEP;
        }

        for (double d = 0; d < traveled; d += 0.3D) {
            Vector3d p = start.add(look.scale(d));
            ((net.minecraft.server.ServerWorld) world).sendParticles(ParticleTypes.END_ROD,
                    p.x, p.y, p.z, 1, 0, 0, 0, 0.0D);
        }

        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.2F, 0.6F + chargePercent * 0.4F);
    }
}
