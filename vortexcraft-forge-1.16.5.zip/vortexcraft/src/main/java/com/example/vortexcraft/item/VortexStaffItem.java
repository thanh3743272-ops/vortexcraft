package com.example.vortexcraft.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

import java.util.List;

/**
 * Vortex Staff v2: GIỮ chuột phải để hút mob/item lại gần và "ghim" chúng lơ lửng
 * quanh người chơi (càng giữ lâu càng gom được nhiều / dính chặt hơn).
 * BUÔNG chuột ra để phóng văng tất cả những gì đang bị hút ra xa theo hướng
 * người chơi đang nhìn - phóng càng mạnh nếu giữ càng lâu (tối đa ở ~2 giây).
 */
public class VortexStaffItem extends Item {

    private static final double RADIUS = 8.0D;
    private static final double HOLD_RADIUS = 2.2D;      // bán kính "ghim" quanh người chơi khi đang giữ
    private static final int MAX_CHARGE_TICKS = 40;       // 2 giây giữ = sạc tối đa
    private static final int COOLDOWN_TICKS = 60;         // 3 giây cooldown sau khi phóng

    public VortexStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.startUsingItem(hand);
        return ActionResult.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000; // giữ được "vô hạn" cho tới khi người chơi tự buông
    }

    @Override
    public UseAction getUseAnimation(ItemStack stack) {
        return UseAction.BOW;
    }

    /** Gọi mỗi tick trong lúc đang GIỮ chuột phải: hút + ghim vật thể lại gần người chơi. */
    @Override
    public void onUsingTick(ItemStack stack, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;
        World world = player.level;
        if (world.isClientSide) return;

        int chargeTicks = this.getUseDuration(stack) - remainingUseTicks;

        AxisAlignedBB area = player.getBoundingBox().inflate(RADIUS);
        List<Entity> nearby = world.getEntities(player, area,
                e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

        for (Entity entity : nearby) {
            Vector3d toPlayer = player.position().add(0, 1.0D, 0).subtract(entity.position());
            double distance = toPlayer.length();
            if (distance < 0.1D) continue;

            Vector3d direction = toPlayer.normalize();

            if (distance <= HOLD_RADIUS) {
                // Đã lọt vào vùng "ghim" gần người chơi: giảm mạnh vận tốc để nó lơ lửng dính lại,
                // càng giữ lâu (chargeTicks lớn) càng ghim chặt (di chuyển càng ít).
                double dampen = Math.max(0.05D, 0.4D - (chargeTicks * 0.01D));
                entity.setDeltaMovement(entity.getDeltaMovement().scale(dampen)
                        .add(direction.x * 0.05D, 0.01D, direction.z * 0.05D));
            } else {
                // Còn ở xa: kéo lại gần như bình thường.
                double strength = Math.min(1.0D, distance / RADIUS) * 0.85D;
                entity.setDeltaMovement(entity.getDeltaMovement()
                        .add(direction.x * strength, direction.y * strength * 0.4D, direction.z * strength));
            }
            entity.hurtMarked = true;
            entity.fallDistance = 0.0F;
        }

        if (chargeTicks % 10 == 0) {
            world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON,
                    SoundCategory.PLAYERS, 0.4F, 1.6F);
        }
    }

    /** Gọi khi người chơi BUÔNG chuột ra: phóng văng vật thể đang bị ghim ra xa. */
    @Override
    public void releaseUsing(ItemStack stack, World world, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;
        if (world.isClientSide) return;

        int chargeTicks = Math.min(this.getUseDuration(stack) - remainingUseTicks, MAX_CHARGE_TICKS);
        if (chargeTicks < 2) return; // giữ quá ngắn thì không tính là sạc, khỏi bắn lung tung

        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS; // 0.0 -> 1.0
        double launchStrength = 0.8D + chargePercent * 2.2D; // sạc đầy phóng mạnh gấp ~3-4 lần

        AxisAlignedBB area = player.getBoundingBox().inflate(RADIUS);
        List<Entity> nearby = world.getEntities(player, area,
                e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

        Vector3d look = player.getLookAngle();

        for (Entity entity : nearby) {
            Vector3d away = entity.position().subtract(player.position());
            double dist = away.length();
            Vector3d direction = dist < 0.1D ? look : away.normalize();

            entity.setDeltaMovement(
                    direction.x * launchStrength,
                    0.25D + chargePercent * 0.35D,
                    direction.z * launchStrength
            );
            entity.hurtMarked = true;
        }

        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.0F, 0.8F + chargePercent * 0.6F);

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        player.swing(player.getUsedItemHand());
    }
}
