package com.example.vortexcraft.item;

import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.IFormattableTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.client.util.ITooltipFlag;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Vortex Staff - TỰ TIẾN HÓA theo số quái bị hạ trong lúc cầm nó (lưu trong NBT
 * "kills" của chính ItemStack, không phải theo player, nên đổi qua gậy khác là mất tiến độ).
 *
 * 5 giai đoạn (0 -> 4), mỗi giai đoạn đổi tên + đổi hình dáng (texture) + mạnh hơn:
 *   0: Gậy Xoáy Thô Sơ          (0 quái)
 *   1: Gậy Xoáy Thức Tỉnh       (10 quái)
 *   2: Trượng Xoáy Tinh Luyện   (30 quái)
 *   3: Trượng Xoáy Cổ Đại       (60 quái)
 *   4: Trượng Hư Không Tối Thượng (100 quái) - mở khóa 2 chiêu tối thượng:
 *      - Chế độ hút: buông ra kích nổ 1 đợt sóng xung kích lan rộng quanh cụm.
 *      - Chế độ tia: bắn thêm 1 tia phụ chếch sang bên, tạo tia đôi.
 */
public class VortexStaffItem extends Item {

    private static final int[] KILL_THRESHOLDS = {0, 10, 30, 60, 100};
    private static final String[] STAGE_NAMES = {
            "Gậy Xoáy Thô Sơ",
            "Gậy Xoáy Thức Tỉnh",
            "Trượng Xoáy Tinh Luyện",
            "Trượng Xoáy Cổ Đại",
            "Trượng Hư Không Tối Thượng"
    };

    // Thông số theo từng giai đoạn (index 0-4)
    private static final double[] PULL_RADIUS      = {8.0, 9.0, 10.0, 11.5, 13.0};
    private static final double[] LAUNCH_MULT      = {1.0, 1.15, 1.3, 1.5, 1.8};
    private static final double[] BEAM_RANGE       = {14.0, 16.0, 18.0, 20.0, 24.0};
    private static final float[] BEAM_MAX_HARDNESS = {1.0F, 1.0F, 1.5F, 2.0F, 3.0F};
    private static final float[] BEAM_DAMAGE_BONUS = {8.0F, 10.0F, 13.0F, 16.0F, 20.0F};
    private static final int[] COOLDOWN_TICKS      = {60, 55, 50, 45, 35};

    private static final double ANCHOR_DISTANCE = 4.0D;
    private static final double ORBIT_RADIUS = 1.4D;
    private static final int MAX_CHARGE_TICKS = 40;
    private static final double BEAM_STEP = 0.4D;

    public VortexStaffItem(Properties properties) {
        super(properties);
    }

    // ================= HỆ THỐNG TIẾN HÓA =================

    public static int getKills(ItemStack stack) {
        return stack.hasTag() ? stack.getTag().getInt("kills") : 0;
    }

    public static int getStage(ItemStack stack) {
        int kills = getKills(stack);
        int stage = 0;
        for (int i = 0; i < KILL_THRESHOLDS.length; i++) {
            if (kills >= KILL_THRESHOLDS[i]) stage = i;
        }
        return stage;
    }

    public static void addKill(ItemStack stack, PlayerEntity player) {
        int before = getStage(stack);
        int kills = getKills(stack) + 1;
        stack.getOrCreateTag().putInt("kills", kills);
        int after = getStage(stack);
        if (after > before) {
            player.sendMessage(new StringTextComponent("✦ Trượng của bạn đã tiến hóa thành: ")
                    .append(new StringTextComponent(STAGE_NAMES[after]).withStyle(TextFormatting.LIGHT_PURPLE)),
                    player.getUUID());
            player.level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                    SoundCategory.PLAYERS, 1.0F, 1.0F);
        }
    }

    @Override
    public ITextComponent getName(ItemStack stack) {
        int stage = getStage(stack);
        return new StringTextComponent(STAGE_NAMES[stage]);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        int stage = getStage(stack);
        int kills = getKills(stack);
        tooltip.add(new StringTextComponent("Quái đã hạ: " + kills).withStyle(TextFormatting.GRAY));
        if (stage < KILL_THRESHOLDS.length - 1) {
            int next = KILL_THRESHOLDS[stage + 1];
            tooltip.add(new StringTextComponent("Tiến hóa tiếp theo (" + STAGE_NAMES[stage + 1] + "): "
                    + kills + "/" + next).withStyle(TextFormatting.DARK_PURPLE));
        } else {
            tooltip.add(new StringTextComponent("Đã đạt cấp tiến hóa tối đa!").withStyle(TextFormatting.GOLD));
        }
        tooltip.add(new StringTextComponent("Giữ chuột phải: hút xoáy | Shift + giữ: tia năng lượng")
                .withStyle(TextFormatting.DARK_GRAY));
    }

    // ================= SỬ DỤNG =================

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getItemInHand(hand);
        stack.getOrCreateTag().putBoolean("beamMode", player.isShiftKeyDown());
        player.startUsingItem(hand);
        return ActionResult.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAction getUseAnimation(ItemStack stack) {
        return UseAction.SPEAR;
    }

    private boolean isBeamMode(ItemStack stack) {
        return stack.hasTag() && stack.getTag().getBoolean("beamMode");
    }

    @Override
    public void onUsingTick(ItemStack stack, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;
        World world = player.level;
        int chargeTicks = Math.min(this.getUseDuration(stack) - remainingUseTicks, MAX_CHARGE_TICKS);
        int stage = getStage(stack);

        if (isBeamMode(stack)) {
            tickBeamCharge(world, player, chargeTicks);
        } else {
            tickVortexPull(world, player, chargeTicks, stage);
        }
    }

    // ================= CHẾ ĐỘ HÚT XOÁY =================

    private void tickVortexPull(World world, PlayerEntity player, int chargeTicks, int stage) {
        Vector3d look = player.getLookAngle();
        Vector3d anchor = player.getEyePosition(1.0F).add(look.scale(ANCHOR_DISTANCE));
        double pullRadius = PULL_RADIUS[stage];

        if (!world.isClientSide) {
            AxisAlignedBB area = player.getBoundingBox().inflate(pullRadius);
            List<Entity> nearby = world.getEntities(player, area,
                    e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

            for (Entity entity : nearby) {
                Vector3d toAnchor = anchor.subtract(entity.position().add(0, entity.getBbHeight() * 0.5D, 0));
                double distance = toAnchor.length();
                if (distance < 0.05D) continue;

                if (distance <= ORBIT_RADIUS + 0.6D) {
                    Vector3d radial = entity.position().subtract(anchor);
                    Vector3d tangent = new Vector3d(-radial.z, 0, radial.x);
                    if (tangent.lengthSqr() > 0.0001D) tangent = tangent.normalize();

                    double spin = 0.10D + (chargeTicks * 0.003D);
                    double inward = (distance - ORBIT_RADIUS) * 0.15D;
                    double dampen = 0.55D;

                    entity.setDeltaMovement(entity.getDeltaMovement().scale(dampen)
                            .add(tangent.x * spin + toAnchor.normalize().x * inward,
                                 toAnchor.y * 0.06D,
                                 tangent.z * spin + toAnchor.normalize().z * inward));
                } else {
                    double strength = Math.min(1.0D, distance / pullRadius) * 0.85D;
                    Vector3d dir = toAnchor.normalize();
                    entity.setDeltaMovement(entity.getDeltaMovement()
                            .add(dir.x * strength, dir.y * strength * 0.5D, dir.z * strength));
                }
                entity.hurtMarked = true;
                entity.fallDistance = 0.0F;
            }

            if (chargeTicks % 10 == 0) {
                world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON,
                        SoundCategory.PLAYERS, 0.4F, 1.6F);
            }
        } else if (chargeTicks % 2 == 0) {
            world.addParticle(ParticleTypes.PORTAL, anchor.x, anchor.y, anchor.z, 0, 0, 0);
        }
    }

    // ================= CHẾ ĐỘ TIA NĂNG LƯỢNG =================

    private void tickBeamCharge(World world, PlayerEntity player, int chargeTicks) {
        Vector3d tip = player.getEyePosition(1.0F).add(player.getLookAngle().scale(1.3D));
        if (world.isClientSide) {
            int density = 1 + chargeTicks / 6;
            for (int i = 0; i < density; i++) {
                world.addParticle(ParticleTypes.END_ROD, tip.x, tip.y, tip.z,
                        (world.random.nextDouble() - 0.5D) * 0.05D,
                        (world.random.nextDouble() - 0.5D) * 0.05D,
                        (world.random.nextDouble() - 0.5D) * 0.05D);
            }
        } else if (chargeTicks % 8 == 0) {
            world.playSound(null, player.blockPosition(), SoundEvents.BEACON_AMBIENT,
                    SoundCategory.PLAYERS, 0.3F, 1.0F + chargeTicks * 0.02F);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, World world, LivingEntity livingEntity, int remainingUseTicks) {
        if (!(livingEntity instanceof PlayerEntity)) return;
        PlayerEntity player = (PlayerEntity) livingEntity;
        if (world.isClientSide) return;

        int chargeTicks = Math.min(this.getUseDuration(stack) - remainingUseTicks, MAX_CHARGE_TICKS);
        int stage = getStage(stack);
        boolean beamMode = isBeamMode(stack);

        if (beamMode) {
            if (chargeTicks >= 2) fireBeam(world, player, chargeTicks, stage);
        } else {
            if (chargeTicks >= 2) launchVortex(world, player, chargeTicks, stage);
        }

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS[stage]);
        player.swing(player.getUsedItemHand());
    }

    private void launchVortex(World world, PlayerEntity player, int chargeTicks, int stage) {
        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS;
        double launchStrength = (0.8D + chargePercent * 2.2D) * LAUNCH_MULT[stage];
        double pullRadius = PULL_RADIUS[stage];

        AxisAlignedBB area = player.getBoundingBox().inflate(pullRadius);
        List<Entity> nearby = world.getEntities(player, area,
                e -> e != player && (e instanceof LivingEntity || e instanceof ItemEntity));

        Vector3d look = player.getLookAngle();
        for (Entity entity : nearby) {
            Vector3d away = entity.position().subtract(player.position());
            double dist = away.length();
            Vector3d direction = dist < 0.1D ? look : away.normalize();

            entity.setDeltaMovement(direction.x * launchStrength,
                    0.25D + chargePercent * 0.35D, direction.z * launchStrength);
            entity.hurtMarked = true;
        }

        // Chiêu tối thượng (giai đoạn 4): sóng xung kích lan rộng, đẩy văng cả những
        // sinh vật KHÔNG bị hút trước đó nếu chúng đứng gần cụm.
        if (stage >= 4) {
            Vector3d anchor = player.getEyePosition(1.0F).add(look.scale(ANCHOR_DISTANCE));
            AxisAlignedBB novaArea = new AxisAlignedBB(anchor.x - 5, anchor.y - 5, anchor.z - 5,
                    anchor.x + 5, anchor.y + 5, anchor.z + 5);
            for (Entity entity : world.getEntities(player, novaArea, e -> e instanceof LivingEntity && e != player)) {
                Vector3d away = entity.position().subtract(anchor);
                double dist = Math.max(0.5D, away.length());
                Vector3d dir = away.normalize();
                entity.setDeltaMovement(entity.getDeltaMovement().add(dir.x * 1.2D, 0.3D, dir.z * 1.2D));
                if (entity instanceof LivingEntity) {
                    ((LivingEntity) entity).hurt(DamageSource.playerAttack(player), 4.0F);
                }
            }
            world.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE,
                    SoundCategory.PLAYERS, 0.8F, 1.4F);
        }

        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.0F, 0.8F + chargePercent * 0.6F);
    }

    private void fireBeam(World world, PlayerEntity player, int chargeTicks, int stage) {
        float chargePercent = chargeTicks / (float) MAX_CHARGE_TICKS;
        float damage = 2.0F + chargePercent * BEAM_DAMAGE_BONUS[stage];
        double knockback = 0.4D + chargePercent * 0.6D;
        double range = BEAM_RANGE[stage];
        float maxHardness = BEAM_MAX_HARDNESS[stage];

        Vector3d start = player.getEyePosition(1.0F);
        Vector3d mainLook = player.getLookAngle();

        shootSingleBeam(world, player, start, mainLook, range, maxHardness, damage, knockback);

        // Chiêu tối thượng (giai đoạn 4): bắn thêm tia phụ chếch 15 độ sang bên -> tia đôi.
        if (stage >= 4) {
            double angle = Math.toRadians(15.0D);
            double cos = Math.cos(angle), sin = Math.sin(angle);
            Vector3d sideLook = new Vector3d(
                    mainLook.x * cos - mainLook.z * sin,
                    mainLook.y,
                    mainLook.x * sin + mainLook.z * cos
            ).normalize();
            shootSingleBeam(world, player, start, sideLook, range * 0.8D, maxHardness, damage * 0.6F, knockback * 0.7D);
        }

        world.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.2F, 0.6F + chargePercent * 0.4F);
    }

    private void shootSingleBeam(World world, PlayerEntity player, Vector3d start, Vector3d look,
                                  double range, float maxHardness, float damage, double knockback) {
        Set<BlockPos> processedBlocks = new HashSet<>();
        Set<Entity> hitEntities = new HashSet<>();

        double traveled = 0.0D;
        while (traveled < range) {
            Vector3d point = start.add(look.scale(traveled));
            BlockPos pos = new BlockPos(point);

            if (processedBlocks.add(pos)) {
                BlockState state = world.getBlockState(pos);
                if (!state.isAir(world, pos)) {
                    float hardness = state.getDestroySpeed(world, pos);
                    if (hardness < 0F || hardness > maxHardness) {
                        break;
                    }
                    world.destroyBlock(pos, true);
                }
            }

            AxisAlignedBB hitBox = new AxisAlignedBB(point.x - 0.6, point.y - 0.6, point.z - 0.6,
                    point.x + 0.6, point.y + 0.6, point.z + 0.6);
            for (Entity entity : world.getEntities(player, hitBox,
                    e -> e != player && e instanceof LivingEntity)) {
                if (hitEntities.add(entity)) {
                    entity.hurt(DamageSource.playerAttack(player), damage);
                    entity.setDeltaMovement(entity.getDeltaMovement().add(
                            look.x * knockback, 0.15D, look.z * knockback));
                    entity.setSecondsOnFire(3);
                }
            }

            traveled += BEAM_STEP;
        }

        for (double d = 0; d < traveled; d += 0.3D) {
            Vector3d p = start.add(look.scale(d));
            ((net.minecraft.world.server.ServerWorld) world).sendParticles(ParticleTypes.END_ROD,
                    p.x, p.y, p.z, 1, 0, 0, 0, 0.0D);
        }
    }
}
