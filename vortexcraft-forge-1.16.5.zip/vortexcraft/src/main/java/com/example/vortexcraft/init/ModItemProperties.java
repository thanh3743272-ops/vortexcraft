package com.example.vortexcraft.init;

import com.example.vortexcraft.VortexCraft;
import com.example.vortexcraft.item.VortexStaffItem;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.ItemModelsProperties;

/**
 * Chỉ chạy ở client: đăng ký các thuộc tính để item model biết chọn đúng
 * texture theo mức tiến hóa (đọc NBT) và hiệu ứng nhấp nháy ở cấp tối đa.
 */
public class ModItemProperties {

    public static void register() {
        ItemModelsProperties.register(ModItems.VORTEX_STAFF.get(),
                new ResourceLocation(VortexCraft.MOD_ID, "stage"),
                (stack, world, entity) -> VortexStaffItem.getStage(stack) / 4.0F);

        ItemModelsProperties.register(ModItems.VORTEX_STAFF.get(),
                new ResourceLocation(VortexCraft.MOD_ID, "glow"),
                (stack, world, entity) -> (System.currentTimeMillis() / 500L) % 2L == 0L ? 1.0F : 0.0F);
    }
}
