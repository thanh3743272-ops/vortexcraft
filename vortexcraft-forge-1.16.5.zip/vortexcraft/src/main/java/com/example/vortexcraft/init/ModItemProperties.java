package com.example.vortexcraft.init;

import com.example.vortexcraft.VortexCraft;
import com.example.vortexcraft.item.VortexStaffItem;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.ItemModelsProperties;

/**
 * Chỉ chạy ở client: đăng ký thuộc tính "vortexcraft:stage" để item model biết
 * chọn đúng texture theo mức tiến hóa hiện tại của cây Vortex Staff (đọc từ NBT).
 */
public class ModItemProperties {

    public static void register() {
        ItemModelsProperties.register(ModItems.VORTEX_STAFF.get(),
                new ResourceLocation(VortexCraft.MOD_ID, "stage"),
                (stack, world, entity) -> VortexStaffItem.getStage(stack) / 4.0F);
    }
}
